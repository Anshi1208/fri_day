import jwt from 'jsonwebtoken'
import { encryptData } from './cryptoUtils.js';
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key' // Set your secret key


// Middleware to authenticate JWT token
export const authenticateJWT = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    return res.status(403).json({ error: 'Access denied' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Unauthorized access' });
    }
    req.user = user;
    next();
  });
}; 

// Function to issue a JWT token
export const generateToken = (user) => {
  return jwt.sign(user, JWT_SECRET, { expiresIn: '1h' });
};


// Example route to issue a token (Login route)
export const loginRoute = (app) => {
  app.post('/login', (req, res) => {
    // Replace with actual user data from the request
    const user = { id: 1, username: 'user' };
    const token = generateToken(user); // Use the generateToken function to create a token

    // Optional: If you need to encrypt the token (You should implement encryptData if needed)
    const tokenData = encryptData(token); // Assuming encryptData is implemented

    res.json({ tokenData });
  });
};