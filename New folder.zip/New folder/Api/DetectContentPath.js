/* eslint-disable no-unused-vars */
import fs from 'fs'
import path from 'path'

import { fileURLToPath } from 'url'
// Get the directory name from the module's URL
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const DetectContentPath = (app) =>{

// Define possible paths
const contentPath1 = path.join(__dirname, '../src/content/');
const contentPath2 = path.join(__dirname, '../../src/content/');

// Determine the active path
let activePath;
if (fs.existsSync(contentPath1)) {
    activePath = contentPath1;
} else if (fs.existsSync(contentPath2)) {
    activePath = contentPath2;
} else {
    throw new Error('No valid content path found.');
}
return { activePath,__dirname }

}


export default DetectContentPath


const loadEnv = (envPaths = ['./.env', '../.env']) => {
    // Iterate through the paths and find the first one that exists
    const envPath = envPaths
      .map((p) => path.resolve(__dirname, p)) // Resolve relative paths to absolute paths
      .find((p) => fs.existsSync(p)); // Check if the path exists
  
    if (envPath) {
      const result = dotenv.config({ path: envPath }); // Load .env file
      console.log(`Loaded .env from: ${envPath}`);
      return result; // Return the result of dotenv.config()
    } else {
      console.warn('No .env file found in the specified paths.');
      return null; // If no .env file is found, return null
    }
  };