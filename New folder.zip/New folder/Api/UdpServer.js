/* eslint-disable no-undef */
import dgram from 'dgram';
import {decodeHexData} from './decrypt_journey2.js'
import { Server } from 'socket.io';
// Initialize UDP server
const udpServer = dgram.createSocket('udp4');
// In-memory store for the latest UDP message
let udpMessages = null;
let decodedData = null
let lastReceivedTime = null;
const UDP_PORT = 8001;  // UDP Port for the server
const HOST = '0.0.0.0';  // Localhost for UDP

// Define API route to fetch UDP messages
export function startUDPServer(app,server) {
  const io = new Server(server, {
    cors: {
      origin: "*"
    }
  });

  // When the UDP server receives a message
udpServer.on('message', (msg, rinfo) => {

  udpMessages = msg.toString('hex').match(/.{1,2}/g).join(' ').toUpperCase(); 
  // console.log("as => ",typeof udpMessages, udpMessages )
  // Decode the sample hex data
 decodedData = decodeHexData(udpMessages)
console.log(decodedData)
  // Update last received time
  lastReceivedTime = Date.now();
      // Emit the message to WebSocket clients
      io.emit('udpData', decodedData);
});

// Bind the UDP server to all interfaces (0.0.0.0)
udpServer.bind(UDP_PORT, HOST, () => {
  console.log(`UDP server listening on ${UDP_PORT}`);
});

  // WebSocket connection handling
  io.on('connection', (socket) => {
    console.log('A client connected');

    socket.on('disconnect', () => {
      console.log('A client disconnected');
    }); 
  });

  app.get('/udp-messages', (req, res) => {
    // Check if we have a recent UDP message
    const currentTime = Date.now();
    const timeDifference = currentTime - (lastReceivedTime || 0);
    // If a UDP message was received recently, return it
    if (decodedData && timeDifference < 2000) {  // For example, 2 seconds window
      return res.json(decodedData);
    } else {
      return res.json(decodedData); 
    }
  });
}
// Graceful shutdown handling
process.on('SIGINT', () => {
  udpServer.close(() => {
    console.log('UDP server closed');
    process.exit();
  });
});
