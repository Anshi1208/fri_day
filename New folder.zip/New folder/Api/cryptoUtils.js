const shift = 5; // Caesar Cipher shift value

// Function to decrypt data (Caesar Cipher)
export function decryptData(data) {
  let decrypt = data
    .split('')
    .map(char => {
      // Decrypt letters (a-z, A-Z)
      if (char.match(/[a-zA-Z]/)) {
        const code = char.charCodeAt(0);
        const base = char.toLowerCase() === char ? 97 : 65; // Check if char is lowercase or uppercase
        return String.fromCharCode(((code - base - shift + 26) % 26) + base);
      }
      // Decrypt numbers (0-9)
      else if (char.match(/[0-9]/)) {
        const code = char.charCodeAt(0);
        return String.fromCharCode(((code - 48 - shift + 10) % 10) + 48); // 48 is ASCII for '0'
      }
      // Decrypt special characters like / and .
      else if (char === ' ') {
        return ' '; // Leave space unchanged
      }
      // Decrypt special characters like / and .
      else if (char === '/') {
        return '.'; // Leave space unchanged
    }
      // Space character, leave unchanged
      else if (char === '.') {
        return '/'; // Leave space unchanged
      }
      return char; // Non-alphabetic, non-numeric characters are not shifted
    })
    .join('');
  return decrypt;
}

// Function to encrypt data (Caesar Cipher)
export function encryptData(data) {
  let encrypt = data
    .split('')
    .map(char => {
      // Encrypt letters (a-z, A-Z)
      if (char.match(/[a-zA-Z]/)) {
        const code = char.charCodeAt(0);
        const base = char.toLowerCase() === char ? 97 : 65; // Check if char is lowercase or uppercase
        return String.fromCharCode(((code - base + shift) % 26) + base);
      }
      // Encrypt numbers (0-9)
      else if (char.match(/[0-9]/)) {
        const code = char.charCodeAt(0);
        return String.fromCharCode(((code - 48 + shift) % 10) + 48); // 48 is ASCII for '0'
      }
      // Encrypt special characters like / and .
      else if (char === ' ') {
        return ' '; // Leave space unchanged
      }
      // Decrypt special characters like / and .
      else if (char === '/') {
        return '.'; // Leave space unchanged
    }
      // Space character, leave unchanged
      else if (char === '.') {
        return '/'; // Leave space unchanged
      }
      return char; // Non-alphabetic, non-numeric characters are not shifted
    })
    .join('');
  return encrypt;
}
