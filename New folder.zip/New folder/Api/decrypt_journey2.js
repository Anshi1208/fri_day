const Encoded_Hex_Data =  '01 00 00 05 DC 09 47 68 61 7A 69 61 62 61 64 05 44 65 6C 68 69 07 4C 75 63 6B 6E 6F 77 '
// Hex to ASCII function to decode station names from hex
function hexToAscii(hex) {
  let str = ''
  for (let i = 0; i < hex.length; i += 2) {
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16))
  }
  return str
}

// Function to convert Unicode hex length into numeric length
function unicodeHexToLength(hexValue) {
  // let unicodeHexToLength = parseInt(String.fromCharCode(parseInt(hexValue, 16)))
    let unicodeHexToLength = parseInt(hexValue, 16)
  // console.log(unicodeHexToLength)
  return unicodeHexToLength
}

// Function to decode hex values into readable data
export function decodeHexData(hexData) {
  // Split the string into an array of bytes
  const hexArray = hexData.split(' ').map((byte) => parseInt(byte, 16))
  // console.log(hexData.split(' '))
  // console.log(hexArray)
  let dataIndex = 0

  // Mute & Unmute Flag (1 byte)
  const muteFlag = hexArray[dataIndex]
  dataIndex += 1
  const muteStatus = muteFlag === 1 ? 'Mute' : 'Unmute'
  // console.log('muteFlag => ', muteFlag)
  // console.log('muteStatus => ', muteStatus)
  // Approx Distance to Next Station (4 bytes)
  const distanceHex = hexArray
    .slice(dataIndex, dataIndex + 4)
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('')
  dataIndex += 4
  const distanceInMeters = parseInt(distanceHex, 16) // Convert hex to decimal
  // console.log('distanceHex => ', distanceHex)
  // console.log('distanceInMeters => ', distanceInMeters)
  // Source Station Name (Unicode Length + Name)
  const sourceLengthHex = hexArray[dataIndex].toString(16).padStart(2, '0') // Unicode hex of length
  const sourceLength = unicodeHexToLength(sourceLengthHex) // Decode to numeric length
  dataIndex += 1
  const sourceHex = hexArray
    .slice(dataIndex, dataIndex + sourceLength)
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('')
  dataIndex += sourceLength

  const sourceStationName = hexToAscii(sourceHex)
  // console.log('sourceLengthHex => ', sourceLengthHex)
  // console.log('sourceLength => ', sourceLength)
  //   console.log('sourceHex => ', sourceHex)
  //  console.log('sourceStationName => ', sourceStationName)
  // Destination Station Name (Unicode Length + Name)
  const destinationLengthHex = hexArray[dataIndex].toString(16).padStart(2, '0')
  const destinationLength = unicodeHexToLength(destinationLengthHex)
  dataIndex += 1
  const destinationHex = hexArray
    .slice(dataIndex, dataIndex + destinationLength)
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('')
  dataIndex += destinationLength
  const destinationStationName = hexToAscii(destinationHex)
  // console.log('destinationLengthHex => ', destinationLengthHex)
  // console.log('destinationLength => ', destinationLength)
  // console.log('destinationHex => ', destinationHex)
  // console.log('destinationStationName => ', destinationStationName)
  // Next Station Name (Unicode Length + Name)
  const nextStationLengthHex = hexArray[dataIndex].toString(16).padStart(2, '0')
  const nextStationLength = unicodeHexToLength(nextStationLengthHex)
  dataIndex += 1
  const nextStationHex = hexArray
    .slice(dataIndex, dataIndex + nextStationLength)
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('')
  dataIndex += nextStationLength
  const nextStationName = hexToAscii(nextStationHex)
  // console.log('nextStationLengthHex => ', nextStationLengthHex)
  // console.log('nextStationLength => ', nextStationLength)
  // console.log('nextStationHex => ', nextStationHex)
  // console.log('nextStationName => ', nextStationName)
  return {
    muteStatus,
    distanceInMeters,
    sourceStationName,
    destinationStationName,
    nextStationName,
  }
}

// Decode the sample hex data
// const decodedData = decodeHexData(Encoded_Hex_Data)

// Output the decoded data
// console.log('Mute & Unmute Status:', decodedData.muteStatus)
// console.log(
//   'Approx Distance to Next Station:',
//   decodedData.distanceInMeters,
//   'meters'
// )
// console.log('Source Station Name:', decodedData.sourceStationName)
// console.log('Destination Station Name:', decodedData.destinationStationName)
// console.log('Next Station Name:', decodedData.nextStationName)
