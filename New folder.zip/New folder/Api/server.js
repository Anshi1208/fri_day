/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import express from 'express'
import cors from 'cors'
import fs from 'fs'
import path, { basename } from 'path'
import { createServer } from 'http'
import { startUDPServer } from './UdpServer.js'
import { authenticateJWT ,loginRoute} from './Authentication.js'
import  DetectContentPath  from './DetectContentPath.js'
import { encryptData } from './cryptoUtils.js';
import { dataManager } from './dataManager.js';
import loadEnv from './loadEnv.js'
import { Transform } from "stream";
import { log } from 'console'
const app = express()

const { activePath} = DetectContentPath(app)

// Custom paths to search for .env file
const envPath = ['./.env', '../.env']; // Define your custom search paths

// Call the loadEnv function with custom paths
const result = loadEnv(envPath);

const PORT = process.env.VITE_SERVER_PORT || 5000

app.use(cors())


app.use(express.json())
const server = createServer(app)
// Start the UDP server after the HTTP server starts
startUDPServer(app,server)

// Use the loginRoute from auth.js to set up the /login route
loginRoute(app);  // This sets up the POST /login route

// Initialize dataManager to set up routes
dataManager(app);



const marker = Buffer.from("pps International Pvt Ltd", "utf-8");
const block = Buffer.concat([marker, Buffer.alloc(128 - marker.length, 0x00)]);
const blockSize = block.length;

/**
 * ✅ Reusable function:
 * Check if file has PPS header + footer
 */
async function hasValidPPS(filePath, stats) {
  if(stats.size < blockSize * 2) {
    return false
  }
  const fd = await fs.promises.open(filePath, "r");
    try{
        const headerBuffer = Buffer.alloc(blockSize);
        const footerBuffer = Buffer.alloc(blockSize);

        await fd.read(headerBuffer, 0, blockSize, 0);
        await fd.read(footerBuffer, 0, blockSize, stats.size - blockSize);
      

        return headerBuffer.equals(block) && footerBuffer.equals(block);
    }finally {
      await fd.close()
    }
  }


    // New function to read music directory
const readDirectory = (directoryPath) => {
  const files = fs.readdirSync(directoryPath)
  const fileList = []
  files.forEach((file) => {
    const fullPath = path.join(directoryPath, file)
    const stats = fs.statSync(fullPath)
    if (stats.isDirectory()) {
      fileList.push({
        name: file,
        type: 'directory',
        children: readDirectory(fullPath),
      })
    } else {
      fileList.push({
        name: file,
        type: 'file',
      })
    }
  })
  return fileList
}

app.get('/:mediaType',authenticateJWT, (req,res) => {
  const { mediaType } = req.params
  const folderPath = path.join(activePath,`${mediaType}`)
  const touristPath = path.join(activePath,`img/${mediaType}`)
  const posterPath = path.join(activePath,`poster/${mediaType}`)
console.log(mediaType);
  try {
    let files = [];

    // Check if folder exists and read files
    if (fs.existsSync(folderPath)) {
      files = readDirectory(folderPath);
      // console.log(`Serving files from: ${folderPath}`,files);
    } else if (fs.existsSync(touristPath)) {
      files = readDirectory(touristPath);
      // console.log(`Serving files from: ${touristPath}`);
    } else if (fs.existsSync(posterPath)) {
      files = readDirectory(posterPath);
      // console.log(`Serving files from: ${posterPath}`);
    } else {
      return res.status(404).json({ error: 'Media files not found' });
    }

    // Encrypt file names before sending the response
    const encryptedFiles = files.map(file => ({
      ...file,
      name: encryptData(file.name), // Encrypt the file name
    }));

    return res.json(encryptedFiles)
  } catch (error) {
    console.error('Error serving the file:', error)
    return res.status(500).json({ error: `Unable to list ${mediaType} files` })
  }
})

// API to serve media files (images/videos) from the 'content' folder
app.get('/:media/:fileName',authenticateJWT, async(req, res) => {
  const { media, fileName } = req.params
  const filePath = path.join(activePath,`${media}/${fileName}`)
  const otherPath = path.join(activePath,`img/${media}/${fileName}`)
  const musicPath = path.join(activePath,`music/${media}/${fileName}`)
// console.log(filePath)
  try {
    // Check if the video file exists first
    if (fs.existsSync(filePath)) {
      const stats = await fs.promises.stat(filePath);
      if(basename(filePath) == "videoAdvertismentTime.txt"){
        return res.sendFile(filePath)
      }
      
      if(stats.isDirectory()){
        console.log("skiping folder ", filePath )
        return res.sendFile(filePath)
      }

      if (!stats.isFile() || !(await hasValidPPS(filePath, stats))) {
              return res.status(403).json({ error: "Invalid PPS header/footer" });
            }
            console.log("aman",basename(filePath))
      
            res.setHeader("Content-Type", "image/jpeg");
            res.setHeader("Content-Disposition", "inline");
      
            const stream = fs.createReadStream(filePath, {
              start: blockSize,
              end: stats.size - blockSize - 1,
            });
            return stream.pipe(res);
    }
    // Check if the poster image exists
    else if (fs.existsSync(otherPath)) {
      // res.setHeader('Content-Disposition', 'inline') // Serve as inline
      // return res.sendFile(otherPath)
      const stats = await fs.promises.stat(otherPath);
            if (!stats.isFile() || !(await hasValidPPS(otherPath, stats))) {
              return res.status(403).json({ error: "Invalid PPS header/footer" });
            }
      
            // res.setHeader("Content-Type", "image/jpeg");
            res.setHeader("Content-Disposition", "inline");
      
            const stream = fs.createReadStream(otherPath, {
              start: blockSize,
              end: stats.size - blockSize - 1,
            });
            return stream.pipe(res);
    }
    else if (fs.existsSync(musicPath)) {
      
      // return res.sendFile(musicPath)

      const stats = await fs.promises.stat(musicPath);
            if (!stats.isFile() || !(await hasValidPPS(musicPath, stats))) {
              return res.status(403).json({ error: "Invalid PPS header/footer" });
            }
      
            res.setHeader("Content-Type", "audio/mpeg");
            res.setHeader("Content-Disposition", "inline");
      
            const data = await fs.promises.readFile(musicPath);
            const content = data.slice(blockSize, data.length - blockSize);
      
            // 🔄 Restore MP3: flip BF FF → FF FB
            for (let i = 0; i < content.length - 1; i++) {
              if (content[i] === 0xbf && content[i + 1] === 0xff) {
                content[i] = 0xff;
                content[i + 1] = 0xfb;
              }
            }
      
            return res.end(content);
    }
    // If neither file exists
    else {
      return res.status(404).json({ error: 'File not found' })
    }
  } catch (error) {
    console.error('Error serving the file:', error)
    return res.status(500).json({ error: 'Internal server error' })
  }
})


app.get('/:folderType/:mediaType/:videoName',  (req, res) => {
  const { folderType, mediaType, videoName } = req.params;
  const videoPath = path.join(activePath,`${folderType}/${mediaType}/${videoName}`);

  try {
    // Check if the requested file is either an .mp4 or .m3 video file
    if ((videoName.endsWith('.mp4') ) && fs.existsSync(videoPath)) {

      fs.stat(videoPath, (err, stats) => {
        if (err || !stats.isFile()) {
          return res.status(404).json({ error: 'File not found' });
        }
    
        const range = req.headers.range;
        if (!range) {
          return res.status(400).send('Unauthorized access');
        }
    
         // Actual playable content size = remove header + footer
        const fileSize = stats.size - 2 * blockSize;
        // const fileSize = stats.size;
        const CHUNK_SIZE = 10 ** 6; // 1MB
        const [start, end] = range
          .replace(/bytes=/, "")
          .split("-")
          .map(Number);
        const chunkStart = start || 0;
        const chunkEnd =
          end || Math.min(chunkStart + CHUNK_SIZE - 1, fileSize - 1);

        const contentLength = chunkEnd - chunkStart + 1;

        res.writeHead(206, {
          "Content-Range": `bytes ${chunkStart}-${chunkEnd}/${fileSize}`,
          "Accept-Ranges": "bytes",
          "Content-Length": contentLength,
          "Content-Type": "video/mp4",
        });

        // const stream = fs.createReadStream(videoPath, {
        //   start: chunkStart,
        //   end: chunkEnd,
        // });
        // 🔥 Shift offsets to skip PPS header and footer
        const stream = fs.createReadStream(videoPath, {
          start: chunkStart + blockSize,
          end: chunkEnd + blockSize,
        });
        stream.pipe(res);
      });

    } 
    
    else if (fs.existsSync(videoPath)) {
      // Serve non-chunked files as a whole if not .mp4 or .m3
      // return res.sendFile(videoPath);
      // Non-video files: just strip PPS and send full content
      fs.stat(videoPath, (err, stats) => {
        if (err || !stats.isFile()) {
          return res.status(404).json({ error: "File not found" });
        }

        const ext = path.extname(videoName).toLowerCase();
        const fd = fs.openSync(videoPath, "r");
        const headerBuffer = Buffer.alloc(blockSize);
        const footerBuffer = Buffer.alloc(blockSize);
        fs.readSync(fd, headerBuffer, 0, blockSize, 0);
        fs.readSync(fd, footerBuffer, 0, blockSize, stats.size - blockSize);
        fs.closeSync(fd);

        // If PPS header/footer missing, skip playing
        if (!headerBuffer.equals(block) || !footerBuffer.equals(block)) {
          console.log(
            `⚠️ PPS header/footer not found. Skipping file: ${videoPath}`
          );
          return res.status(403).send("File cannot be played");
        }

        if (ext === ".mp3") {
          // MP3: strip PPS + reverse FF FB → FB FF
          res.setHeader("Content-Type", "audio/mpeg");

          const readStream = fs.createReadStream(videoPath, {
            start: blockSize,
            end: stats.size - blockSize - 1,
          });

          // Transform to flip BF FF → FF FB
          const flipTransform = new Transform({
            transform(chunk, encoding, callback) {
              for (let i = 0; i < chunk.length - 1; i++) {
                if (chunk[i] === 0xbf && chunk[i + 1] === 0xff) {
                  chunk[i] = 0xff;
                  chunk[i + 1] = 0xfb;
                }
              }
              callback(null, chunk);
            },
          });

          readStream.pipe(flipTransform).pipe(res);
        } else {
          // Other files: just strip PPS header/footer
          // res.setHeader("Content-Type", "application/octet-stream");
          // const readStream = fs.createReadStream(videoPath, {
          //   start: blockSize,
          //   end: stats.size - blockSize - 1,
          // });
          // readStream.pipe(res);
        }
      });
    }  else {
      // File not found
      return res.status(404).json({ error: 'Video or poster not found' });
    }
  } catch (error) {
    console.error('Error serving the file:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


app.get('/poster/:mediaType',authenticateJWT, (req,res) => {
  const { mediaType } = req.params
  const PosterPath = path.join(activePath,`poster/${mediaType}`)

  try {
    if (fs.existsSync(PosterPath)) {
      const files = readDirectory(PosterPath)
      // console.log(files)
      res.json(files)
    } else {
      return res.status(404).json({ error: 'Video or poster not found' })
    }
  } catch (error) {
    console.error('Error serving the file:', error)
    return res.status(500).json({ error: `Unable to list ${mediaType} files` })
  }
})


app.get('/poster/:folderType/:mediaType/:posterName', authenticateJWT,  async(req, res) => {
  const { folderType, mediaType, posterName } = req.params;

  const posterPath = path.join(activePath,'poster',`${folderType}/${mediaType}/${posterName}`);

  // console.log(posterPath)
  if (fs.existsSync(posterPath)) {
    // Serve the poster image
    // return res.sendFile(posterPath);
    const stats = await fs.promises.stat(posterPath);
    if (!stats.isFile() || !(await hasValidPPS(posterPath, stats))) {
      return res.status(403).json({ error: "Invalid PPS header/footer" });
    }

    // res.setHeader("Content-Type", "image/jpeg");
    res.setHeader("Content-Disposition", "inline");

    const stream = fs.createReadStream(posterPath, {
      start: blockSize,
      end: stats.size - blockSize - 1,
    });
    return stream.pipe(res);
    
  } else {
    // File not found
    return res.status(404).json({ error: 'poster not found' });
  }
})

// Global error handler
app.use((error, req, res, next) => {
  console.error(`Global error handler caught an error: ${error.message}`)

  // Send a response to the client
  res.status(500).send('An unexpected error occurred')

  // After sending the response, restart the server after 10 seconds
  server.close(() => {
    console.log('Server is restarting after an error...')
    setTimeout(startServerWithRetry, 5000) // Restart server after 10 seconds
  })
})

const startServerWithRetry = () => {
  try {
    server.listen(PORT, '0.0.0.0', () => {
      console.log(`Server is running on port ${PORT}`)
    })
  } catch (error) {
    console.error(`Server encountered an error: ${error.message}`)
    console.log('Retrying server startup in 10 seconds...')
    setTimeout(startServerWithRetry, 10000)
  }
}

// Catch uncaught exceptions and unhandled promise rejections
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error.message)
  server.close(() => {
    console.log('Server is restarting after an uncaught exception...')
    setTimeout(startServerWithRetry, 10000)
  })
})

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason)
  server.close(() => {
    console.log('Server is restarting after an unhandled rejection...')
    setTimeout(startServerWithRetry, 10000)
  })
})

// Start server with retry logic
startServerWithRetry()
