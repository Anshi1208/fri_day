/* eslint-disable no-undef */
import { io } from "socket.io-client";

// Determine WebSocket server URL dynamically
let serverUrl;
import dotenv from "dotenv";

// Load environment variables from .env file
dotenv.config();

// Get the server port from environment variables (default to 5000 if not set)
const SERVER_PORT = process.env.VITE_SERVER_PORT || 5000;
const SERVER_HOST = process.env.VITE_SERVER_HOST || "192.168.0.243"; // Replace with actual IP

const serverUrl2 = `http://${SERVER_HOST}:${SERVER_PORT}`;

console.log(`Using WebSocket server URL: ${serverUrl2}`);
if (typeof window !== "undefined") {
  // Browser environment
  serverUrl = `${window.location.protocol}//${window.location.hostname}:${process.env.VITE_SERVER_PORT}`;
} else {
  // Node.js environment (set manually or use env variable)
  serverUrl = `${serverUrl2}`;  // Replace with actual server IP
}

const socket = io(serverUrl, {
  transports: ["websocket"], // Ensure compatibility with mobile devices
});

socket.on("connect", () => {
  console.log(`Connected to WebSocket server at ${serverUrl}`);
});

// Listen for UDP messages from the server
socket.on("udpData", (data) => {
  console.log("Received UDP message:", data);
});

// Handle disconnection
socket.on("disconnect", () => {
  console.log("Disconnected from WebSocket server");
});
