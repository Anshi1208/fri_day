import dgram from 'dgram'

const udpServer = dgram.createSocket('udp4')

const PORT = 8001 // UDP port to receive data
const HOST = '127.0.0.1' // Loopback IP

// When the server receives a UDP message
udpServer.on('message', (msg, rinfo) => {
  console.log(`Received message: ${msg} from ${rinfo.address}:${rinfo.port}`)
})

// Bind the UDP server to the PORT and HOST
udpServer.bind(PORT, HOST)

// Handle graceful shutdown
process.on('SIGINT', () => {
  udpServer.close(() => {
    console.log('UDP server closed')
    process.exit()
  })
})
