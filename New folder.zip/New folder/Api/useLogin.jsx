import React, { useState, useEffect } from 'react';
import { decryptData } from './cryptoUtils';

const useLogin = () => {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [error, setError] = useState(null); // New state for error handling

  const handleLogin = async () => {
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username: 'Aman Modanwal' }),
      });


      // console.log(response)
      if (!response.ok) {
        throw new Error('Login failed with status: ' + response.status);
      }

      const data = await response.json();
      // console.log(data.tokenData);

      const decrypttoken = decryptData(data.tokenData);

      if (decrypttoken) {
        localStorage.setItem('token', decrypttoken);
        setToken(decrypttoken);
        return decrypttoken; // Return the token on successful login
      } else {
        throw new Error('No token received');
      }
    } catch (error) {
      setError(error.message);  // Set the error message
      console.error(error);
    }
  };

  useEffect(() => {
    handleLogin(); // Attempt login when the server IP is available
  }, []);  // Empty dependency array ensures login happens once

  return { token, error };
};

export default useLogin;
