// server.js (ESM)
import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const adsDir = path.join(__dirname, "ads");

// Serve static ad files
app.use("/ads", express.static(adsDir));

// API: return array of ad URLs
app.get("/api/ads", (req, res) => {
  try {
    const allFiles = fs.readdirSync(adsDir);
    const files = allFiles.filter((f) => {
      const ext = f.toLowerCase().split(".").pop();
      return ["mp4", "jpg", "jpeg", "png", "gif", "webp"].includes(ext);
    });
    const PORT = process.env.PORT || 5000;
    const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

    const urls = files.map((f) => `/ads/${encodeURIComponent(f)}`);

    res.json(urls);
  } catch (err) {
    console.error("Error reading ads:", err);
    res.status(500).json({ error: "Could not read ads" });
  }
});

// API: read interval.txt
app.get("/api/ad-interval", (req, res) => {
  const filePath = path.join(adsDir, "interval.txt");
  try {
    if (fs.existsSync(filePath)) {
      const txt = fs.readFileSync(filePath, "utf8").trim();
      const num = Number(txt);

      if (!Number.isFinite(num) || num <= 0) {
        return res.json({ minutes: 1 });
      }

      return res.json({ minutes: Math.max(1, Math.floor(num)) });
    }

    res.json({ minutes: 1 });
  } catch (err) {
    console.warn("Failed to read interval:", err);
    res.json({ minutes: 1 });
  }
});

// root
app.get("/", (req, res) => {
  res.send("Backend running. Use /api/ads and /api/ad-interval");
});

app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
