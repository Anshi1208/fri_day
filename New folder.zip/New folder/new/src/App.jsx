import React from "react";
import VideoPlayer from "./VideoPlayer";
import VideoPlaylist from "./VideoPlayList.jsx";

const App = () => {
  // console.log("APP loaded");
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#111",
        color: "#fff",
        padding: 16,
      }}
    >
      <h1 style={{ margin: 0, paddingBottom: 12 }}>React Video Player</h1>
      <VideoPlaylist/>
      {/* <VideoPlayer /> */}
    </div>
  );
};

export default App;
