import React, { useState, useEffect } from "react";
import VideoPlayer from "./VideoPlayer";
import "./index.css";

const BASE_API = window.location.hostname.startsWith("localhost")
  ? "http://localhost:5000"
  : `http://${window.location.hostname}:5000`;

const ADS_API = `${BASE_API}/api/ads`;
const INTERVAL_API = `${BASE_API}/api/ad-interval`;

const isImage = (u) => /\.(jpg|jpeg|png|gif|webp)$/i.test(u);
const isVideo = (u) => /\.(mp4|mov|webm|mkv)$/i.test(u);

// Fetch videos from public/videos.json
const fetchVideosFromJSON = () => {
  return fetch("/videos.json").then((res) => res.json());
};

export default function VideoPlaylist() {
  const [videos, setVideos] = useState([]);
  const [selectedVideoUrl, setSelectedVideoUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const [ads, setAds] = useState([]);
  const [intervalMin, setIntervalMin] = useState(1);

  // Fetch videos
  useEffect(() => {
    setIsLoading(true);
    fetchVideosFromJSON()
      .then((data) => {
        setVideos(data);
        if (data.length > 0) {
          setSelectedVideoUrl(data[0].url);
        }
      })
      .catch(console.error)
      .finally(() => setIsLoading(false));
  }, []);

  // ✅ Fetch ads + interval (FIXED)
  useEffect(() => {
    // Fetch ads
    fetch(ADS_API)
      .then((r) => r.json())
      .then((d) => {
        const allAds = Array.isArray(d)
          ? d
              .filter((url) => isImage(url) || isVideo(url))
              .map((url) => (url.startsWith("http") ? url : BASE_API + url))
          : [];

        console.log("✅ Loaded", allAds.length, "ads");
        setAds(allAds);
      })
      .catch((err) => console.error("❌ Error fetching ads:", err));

    // Fetch interval
    fetch(INTERVAL_API)
      .then((r) => r.json())
      .then((d) => {
        if (typeof d?.minutes === "number") {
          console.log("✅ Ad interval:", d.minutes);
          setIntervalMin(d.minutes);
        }
      })
      .catch((err) => console.error("❌ Error reading interval:", err));
  }, []);

  const currentVideoTitle = videos.find(
    (v) => v.url === selectedVideoUrl
  )?.title;

  return (
    <div className="video-app-container">
      <div className="playlist-section-top">
        <h3>Now Playing: {currentVideoTitle || "N/A"}</h3>
        <p>
          Ad Interval: {intervalMin} min | Total Ads: {ads.length}
        </p>

        {isLoading ? (
          <p>Loading videos...</p>
        ) : (
          <ul className="video-list-horizontal">
            {videos.map((video) => (
              <li
                key={video.id}
                className={selectedVideoUrl === video.url ? "active" : ""}
                onClick={() => setSelectedVideoUrl(video.url)}
              >
                {video.title}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="player-section-bottom">
        <VideoPlayer
          videoSource={selectedVideoUrl}
          videos={videos}
          setSelectedVideoUrl={setSelectedVideoUrl}
          ads={ads}
          intervalMin={intervalMin}
        />
      </div>
    </div>
  );
}
