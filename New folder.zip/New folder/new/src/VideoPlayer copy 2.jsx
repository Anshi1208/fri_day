import React, { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";

const ADS_API = "http://localhost:5000/api/ads";
const INTERVAL_API = "http://localhost:5000/api/ad-interval";
const KEY = "last_played_video_resume";
const IMAGE_AD_DURATION = 5; // Display image ads for 5 seconds

const isImage = (u) => /\.(jpg|jpeg|png|gif|webp)$/i.test(u);
const isVideo = (u) => /\.(mp4|mov|webm|mkv)$/i.test(u);
const fmt = (s = 0) =>
  !isFinite(s)
    ? "00:00"
    : `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(
        Math.floor(s % 60)
      ).padStart(2, "0")}`;

const getResume = () => JSON.parse(localStorage.getItem(KEY) || "null");
const saveResume = (url, time) =>
  localStorage.setItem(KEY, JSON.stringify({ url, time }));

export default function VideoPlayer({
  videoSource,
  goToNext,
  goToPrevious,
  canGoNext,
  canGoPrevious,
}) {
  const container = useRef(null);
  const wrap = useRef(null);
  const main = useRef(null);
  const ad = useRef(null);
  const mainEl = useRef(null);
  const adContainer = useRef(null);

  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [paused, setPaused] = useState(true);
  const [rate, setRate] = useState(1);
  const [vol, setVol] = useState(1);
  const [visible, setVisible] = useState(true);
  const [locked, setLocked] = useState(false);
  const [bright, setBright] = useState(0.5);
  const [showSpeed, setShowSpeed] = useState(false);
  const [pip, setPip] = useState(false);
  const adCount = useRef(0);

  const [ads, setAds] = useState([]);
  const [intervalMin, setIntervalMin] = useState(3);
  const [adPlaying, setAdPlaying] = useState(false);

  const seeking = useRef(false);
  const hideT = useRef(null);
  const saveT = useRef(0);
  const nextAd = useRef(null);
  const triggering = useRef(false);
  const imageAdTimer = useRef(null);

  /* ---------------- Fetch Ads ---------------- */
  useEffect(() => {
    console.log("🔄 Fetching ads...");
    fetch(ADS_API)
      .then((r) => r.json())
      .then((d) => {
        console.log("📦 Ads received:", d);
        // Keep BOTH image and video ads
        const allAds = Array.isArray(d)
          ? d.filter((url) => isImage(url) || isVideo(url))
          : [];
        console.log("🎬 All ads (images + videos):", allAds);
        setAds(allAds);
      })
      .catch((err) => console.error("❌ Error fetching ads:", err));

    console.log("🔄 Fetching interval...");
    fetch(INTERVAL_API)
      .then((r) => r.json())
      .then((d) => {
        console.log("⏱ Interval response:", d);
        if (typeof d?.minutes === "number") {
          setIntervalMin(d.minutes);
          console.log("⏱ Interval set:", d.minutes, "minutes");
        }
      })
      .catch((err) => console.error("❌ Error reading interval:", err));
  }, []);

  const showControls = () => {
    if (locked) return;
    clearTimeout(hideT.current);
    setVisible(true);
    if (!paused) hideT.current = setTimeout(() => setVisible(false), 3000);
  };

  /* ---------------- Volume / Rate ---------------- */
  const changeRate = (r) => {
    if (!main.current) return;
    main.current.playbackRate(r);
    setRate(r);
  };

  /* ---------------- PiP / Fullscreen ---------------- */
  const toggleFS = async () =>
    document.fullscreenElement
      ? document.exitFullscreen()
      : container.current?.requestFullscreen().catch(() => {});

  const togglePiP = async () => {
    const v = main.current?.tech()?.el();
    if (!v) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPip(false);
      } else {
        await v.requestPictureInPicture();
        setPip(true);
      }
    } catch {}
  };

  /* ---------------- Ad Start (FIXED FOR IMAGES + VIDEOS) ---------------- */
  const startAd = () => {
    if (!ads.length || adPlaying || triggering.current) return;

    const url = ads[Math.floor(Math.random() * ads.length)];
    const p = main.current;
    if (!url || !p) return;

    const resume = p.currentTime();
    p.pause();

    triggering.current = true;
    setAdPlaying(true);
    setPaused(true);

    // Hide main video wrapper (not just the video element)
    wrap.current.style.visibility = "hidden";

    // Create ad container div - OUTSIDE the filtered wrap
    const adDiv = document.createElement("div");
    adDiv.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: #000;
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
    adContainer.current = adDiv;
    container.current.appendChild(adDiv);

    const endAd = () => {
      console.log("🏁 Ad ended. Restoring main video...");

      // Clear image timer if exists
      if (imageAdTimer.current) {
        clearTimeout(imageAdTimer.current);
        imageAdTimer.current = null;
      }

      // Properly dispose of ad player if it's a video
      if (ad.current) {
        ad.current.dispose();
        ad.current = null;
      }

      // Remove ad container
      if (adContainer.current) {
        adContainer.current.remove();
        adContainer.current = null;
      }

      // Restore main video wrapper
      if (wrap.current) {
        wrap.current.style.visibility = "visible";
      }

      p.currentTime(resume);
      console.log("⏯ Resuming main video at:", resume);
      p.play();

      setAdPlaying(false);
      setPaused(false);
      triggering.current = false;

      const intSec = Math.max(1, intervalMin * 60);

      // Increase ad count strictly
      adCount.current += 1;

      // Schedule next clean interval ad
      nextAd.current = (adCount.current + 1) * intSec;

      console.log("📌 Next ad scheduled at:", nextAd.current);
    };

    // Handle IMAGE ads
    if (isImage(url)) {
      console.log("🖼️ Displaying image ad:", url);

      const img = document.createElement("img");
      img.src = url;
      img.style.cssText = `
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
        display: block;
      `;

      img.onerror = () => {
        console.error("❌ Image ad failed to load:", url);
        endAd();
      };

      img.onload = () => {
        console.log("✅ Image ad loaded successfully");
      };

      adDiv.appendChild(img);

      // Auto-close after IMAGE_AD_DURATION seconds
      imageAdTimer.current = setTimeout(endAd, IMAGE_AD_DURATION * 1000);
      return;
    }

    // Handle VIDEO ads
    if (isVideo(url)) {
      console.log("🎬 Playing video ad:", url);

      const vid = document.createElement("video");
      vid.className = "video-js vjs-default-skin";
      vid.style.cssText = `
        width: 100%;
        height: 100%;
        object-fit: contain;
      `;
      vid.setAttribute("playsinline", "");
      vid.setAttribute("webkit-playsinline", "");

      adDiv.appendChild(vid);

      // Initialize Video.js player for ad
      const adPlayer = videojs(vid, {
        controls: false,
        autoplay: true,
        preload: "auto",
        muted: false,
        sources: [{ src: url, type: "video/mp4" }],
      });

      ad.current = adPlayer;

      adPlayer.on("error", (err) => {
        console.error("❌ Ad playback error:", err);
        endAd();
      });

      adPlayer.on("ended", endAd);

      adPlayer.ready(() => {
        console.log("✅ Ad player ready, playing:", url);
      });
    }
  };

  /* ---------------- Build Player ---------------- */
  useEffect(() => {
    if (!videoSource) {
      main.current?.dispose();
      wrap.current.innerHTML = "";
      return;
    }

    main.current?.dispose();
    wrap.current.innerHTML = "";

    if (isImage(videoSource)) {
      const img = document.createElement("img");
      img.src = videoSource;
      img.style.cssText = "width:100%;height:100%;object-fit:contain;";
      wrap.current.appendChild(img);
      return;
    }

    const el = document.createElement("video");
    el.className = "video-js vjs-default-skin";
    el.setAttribute("playsinline", "");
    el.setAttribute("webkit-playsinline", "");
    el.style.cssText = "width:100%;height:100%;object-fit:contain;";
    wrap.current.appendChild(el);

    const player = videojs(el, {
      controls: false,
      preload: "auto",
      autoplay: true,
      fluid: true,
      sources: [{ src: videoSource, type: "video/mp4" }],
      playbackRates: [0.5, 1, 1.25, 1.5, 2],
    });

    main.current = player;
    setVol(player.volume());

    const resume = getResume();

    player.on("loadedmetadata", () => {
      const dur = player.duration();
      setDuration(dur);

      const resumeTime =
        resume && resume.url === videoSource
          ? Math.min(dur - 1, resume.time)
          : 0;

      player.currentTime(resumeTime);
      setCurrent(resumeTime);

      const intSec = Math.max(1, intervalMin * 60);

      // How many ads have already passed from start → resumeTime
      adCount.current = Math.floor(resumeTime / intSec);

      // Schedule next clean interval
      nextAd.current = (adCount.current + 1) * intSec;

      console.log("⏱ CLEAN SCHEDULE → Next ad at:", nextAd.current);
    });

    player.on("timeupdate", () => {
      if (adPlaying) return;

      const t = player.currentTime();
      if (!seeking.current) setCurrent(t);

      const now = Date.now();
      if (now - saveT.current > 2000) {
        saveResume(videoSource, t);
        saveT.current = now;
      }

      // Fire ad EXACTLY at the right second
      if (!triggering.current && Math.abs(t - nextAd.current) < 0.3) {
        console.log("🚀 Ad Trigger at:", t);
        startAd();
      }
    });

    player.on("pause", () => {
      if (!adPlaying) {
        saveResume(videoSource, player.currentTime());
        setPaused(true);
      }
    });

    player.on("play", () => !adPlaying && setPaused(false));
    player.on("volumechange", () => setVol(player.volume()));
    player.on("ended", () => goToNext?.());

    return () => player.dispose();
  }, [videoSource, intervalMin]);

  /* ---------------- Save on unload ---------------- */
  useEffect(() => {
    const save = () => {
      if (main.current && !adPlaying)
        saveResume(videoSource, main.current.currentTime());
    };
    window.addEventListener("beforeunload", save);
    const visHandler = () => {
      if (document.visibilityState === "hidden") save();
    };
    document.addEventListener("visibilitychange", visHandler);
    return () => {
      window.removeEventListener("beforeunload", save);
      document.removeEventListener("visibilitychange", visHandler);
    };
  }, [videoSource, adPlaying]);

  /* ---------------- UI Handlers ---------------- */
  const togglePlay = () => {
    if (locked || adPlaying) return;
    const p = main.current;
    p.paused() ? p.play() : p.pause();
    showControls();
  };

  const seek = (v) => {
    if (locked || adPlaying) return;
    setCurrent(v);
    main.current.currentTime(v);

    const intSec = Math.max(1, intervalMin * 60);
    nextAd.current = (Math.floor(v / intSec) + 1) * intSec;
  };

  /* ---------------- Render ---------------- */
  return (
    <div
      className={`vp-container ${locked ? "locked" : ""}`}
      ref={container}
      onClick={showControls}
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        background: "#000",
      }}
    >
      {!videoSource && (
        <div className="no-video-message">
          <h3>Select a video to begin playing.</h3>
        </div>
      )}

      <div
        ref={wrap}
        className="video-wrapper"
        style={{
          position: "relative",
          background: "#000",
          height: "100%",
          width: "100%",
          filter: `brightness(${0.5 + Number(bright)})`,
        }}
      />

      {videoSource && (
        <>
          {/* LOCK */}
          <button
            className={`lock-btn ${visible ? "show" : ""} ${
              locked ? "active" : ""
            }`}
            onClick={() => setLocked((x) => !x)}
            style={{
              position: "absolute",
              top: 10,
              left: "50%",
              transform: "translateX(-50%)",
              zIndex: 30,
            }}
          >
            {locked ? "🔒" : "🔓"}
          </button>

          {/* Brightness */}
          {!locked && !adPlaying && (
            <div
              className={`right-vertical-brightness ${visible ? "show" : ""}`}
            >
              <div>☀️</div>

              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                className="vertical-slider"
                value={bright}
                onChange={(e) => setBright(e.target.value)}
              />
            </div>
          )}

          {/* Volume (left) */}
          {!locked && !adPlaying && (
            <div className={`left-vertical-volume ${visible ? "show" : ""}`}>
              <div>🔊</div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                className="vertical-slider"
                value={vol}
                onChange={(e) => {
                  main.current.volume(e.target.value);
                  setVol(e.target.value);
                }}
              />
            </div>
          )}

          {/* Center Controls */}
          {!locked && !adPlaying && (
            <div
              className={`center-controls ${visible ? "show" : ""}`}
              style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                transform: "translate(-50%,-50%)",
                zIndex: 30,
                display: "flex",
                gap: 8,
              }}
            >
              <button onClick={goToPrevious} disabled={!canGoPrevious}>
                ⏮
              </button>
              <button onClick={() => seek(Math.max(0, current - 10))}>
                ⟲ 10s
              </button>
              <button onClick={togglePlay}>{paused ? "►" : "❚❚"}</button>
              <button onClick={() => seek(Math.min(duration, current + 10))}>
                ⟳ 10s
              </button>
              <button onClick={goToNext} disabled={!canGoNext}>
                ⏭
              </button>
            </div>
          )}

          {/* Bottom Controls */}
          {!locked && !adPlaying && (
            <div
              className={`v-controls ${visible ? "visible" : "hidden"}`}
              style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                padding: "8px 12px",
                display: "flex",
                alignItems: "center",
                zIndex: 40,
                background:
                  "linear-gradient(0deg,rgba(0,0,0,0.6),rgba(0,0,0,0))",
              }}
            >
              <div>{fmt(current)}</div>

              <input
                type="range"
                min={0}
                max={duration}
                step="0.1"
                value={current}
                onChange={(e) => seek(Number(e.target.value))}
                style={{ flex: 1 }}
              />

              <div>{fmt(duration)}</div>

              <div style={{ position: "relative" }}>
                <button onClick={() => setShowSpeed((x) => !x)}>{rate}x</button>

                {showSpeed && (
                  <div
                    style={{
                      position: "absolute",
                      right: 0,
                      bottom: "120%",
                      background: "#222",
                      color: "#fff",
                      padding: 8,
                      borderRadius: 6,
                    }}
                  >
                    {[0.5, 1, 1.25, 1.5, 2].map((r) => (
                      <div
                        key={r}
                        style={{
                          padding: "6px",
                          cursor: "pointer",
                          fontWeight: r === rate ? 700 : 400,
                        }}
                        onClick={() => {
                          changeRate(r);
                          setShowSpeed(false);
                        }}
                      >
                        {r}x
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <button onClick={toggleFS}>⛶</button>
              <button onClick={togglePiP}>{pip ? "⤧" : "⧉"}</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
