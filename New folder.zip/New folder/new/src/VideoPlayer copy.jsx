import React, { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";
import "./index.css";

const fmt = (s = 0) => {
  if (!isFinite(s)) return "00:00";
  const mm = Math.floor(s / 60)
    .toString()
    .padStart(2, "0");
  const ss = Math.floor(s % 60)
    .toString()
    .padStart(2, "0");
  return `${mm}:${ss}`;
};

// Accepts videoSource URL and new navigation props
export default function VideoPlayer({
  videoSource,
  goToNext,
  goToPrevious,
  canGoNext,
  canGoPrevious,
}) {
  const containerRef = useRef(null);
  const videoWrapperRef = useRef(null);
  const playerRef = useRef(null);
  const [brightness, setBrightness] = useState(0.5);
  const [isPaused, setIsPaused] = useState(true);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [isPiP, setIsPiP] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [isLocked, setIsLocked] = useState(false); // 1. New Lock State
  const hideTimeout = useRef(null);
  const seekingRef = useRef(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);


  // --- Controls Visibility Logic ---

  const showControls = (force = false) => {
    if (isLocked) return; // Ignore if locked

    if (hideTimeout.current) {
      clearTimeout(hideTimeout.current);
      hideTimeout.current = null;
    }
    setControlsVisible(true);

    const p = playerRef.current;
    if (!p) return;

    // Set auto-hide timeout only if playing and not forced open
    if (!p.paused() && !force) {
      hideTimeout.current = setTimeout(() => setControlsVisible(false), 3000);
    }
  };
  const showControlsTemporarily = () => showControls(false);

  // --- Player Interaction Handlers ---

  const togglePlay = (e) => {
    e?.stopPropagation();
    if (!playerRef.current || isLocked) return; // Ignore if locked
    if (playerRef.current.paused()) playerRef.current.play();
    else playerRef.current.pause();
    showControls(true);
  };

  const onSeekStart = () => {
    if (isLocked) return; // Ignore if locked
    seekingRef.current = true;
    if (hideTimeout.current) clearTimeout(hideTimeout.current);
  };
  const onSeekChange = (value) => {
    if (!playerRef.current || isLocked) return; // Ignore if locked
    seekingRef.current = true;
    setCurrent(Number(value));
  };
  const onSeekEnd = (value) => {
    if (!playerRef.current || isLocked) return; // Ignore if locked
    playerRef.current.currentTime(Number(value));
    seekingRef.current = false;
    showControls(true);
  };

  const changeRate = (r) => {
    if (!playerRef.current || isLocked) return; // Ignore if locked
    playerRef.current.playbackRate(r);
    setPlaybackRate(r);
    showControls(true);
  };

  const toggleFullscreen = async () => {
    if (isLocked) return; // Ignore if locked
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await el.requestFullscreen().catch(() => {});
    }
  };

  const togglePiP = async () => {
    if (isLocked) return; // Ignore if locked
    const p = playerRef.current;
    if (!p) return;
    try {
      if (isPiP) await p.exitPictureInPicture();
      else await p.requestPictureInPicture();
    } catch (err) {
      console.warn("PiP not supported:", err);
    }
  };

  const onVolumeChange = (v) => {
    if (isLocked) return; // Ignore if locked
    if (!playerRef.current) return;
    playerRef.current.volume(Number(v));
    setVolume(Number(v));
    showControls(true);
  };

  // 2. Function to toggle lock
  const toggleLock = (e) => {
    e?.stopPropagation();
    const newState = !isLocked;
    setIsLocked(newState);
    // When unlocking, immediately show controls
    if (!newState) {
      showControls(true);
    } else {
      // When locking, hide all non-lock controls
      setControlsVisible(false);
    }
  };

  // --- Effects ---

  // Core Effect: Initialize Player and Handle Source Change
  useEffect(() => {
    if (!videoSource) {
      if (playerRef.current) playerRef.current.pause();
      return;
    }

    let p = playerRef.current; // 1. Initialize player if it doesn't exist

    if (!p) {
      const el = document.createElement("video-js");
      el.className = "vjs-tech";
      if (videoWrapperRef.current) videoWrapperRef.current.appendChild(el);

      p = videojs(el, {
        controls: false,
        preload: "auto",
        fluid: false,
        autoplay: true,
        sources: [{ src: videoSource, type: "video/mp4" }],
        playbackRates: [0.5, 1, 1.25, 1.5, 2],
        textTrackSettings: false,
      });
      playerRef.current = p; // 2. Setup all event listeners (only once)

      p.on("loadedmetadata", () => {
        setDuration(p.duration() || 0);
        setCurrent(p.currentTime() || 0);
      });
      p.on("timeupdate", () => {
        if (!seekingRef.current) setCurrent(p.currentTime() || 0);
      });
      p.on("play", () => {
        setIsPaused(false);
        showControlsTemporarily();
      });
      p.on("pause", () => {
        setIsPaused(true);
        showControls(true);
      });
      p.on("volumechange", () => {
        setVolume(p.volume());
      });
      p.on("enterpictureinpicture", () => setIsPiP(true));
      p.on("leavepictureinpicture", () => setIsPiP(false));

      // OPTIONAL: Auto-play next video on 'ended' event
      p.on("ended", () => {
        if (goToNext) {
          goToNext();
        }
      });
    } else {
      // 3. If player exists, just change the source and play
      p.src([{ src: videoSource, type: "video/mp4" }]);
      p.load();
      p.play();
      setIsPaused(false);
    }

    return () => {
      // Dispose logic runs only on full component unmount
      if (p && !videoSource && playerRef.current) {
        p.dispose();
        playerRef.current = null;
      }
    }; // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoSource, goToNext]);

  // Mouse move/touch handler to show controls
  useEffect(() => {
    const c = containerRef.current;
    if (!c) return;

    // Clear any existing timeout on state change
    if (hideTimeout.current) clearTimeout(hideTimeout.current);

    const handleInteraction = () => {
      // If locked, an interaction only shows the controls *temporarily*
      // (This only makes the lock button visible)
      if (isLocked) {
        setControlsVisible(true);
        // Set a timeout to hide the single unlock button after 3 seconds
        if (hideTimeout.current) clearTimeout(hideTimeout.current);
        hideTimeout.current = setTimeout(() => setControlsVisible(false), 3000);
      } else {
        // If unlocked, show controls normally
        showControlsTemporarily();
      }
    };

    // Use 'mousemove' and 'touchstart' to show controls on interaction
    c.addEventListener("mousemove", handleInteraction);
    c.addEventListener("touchstart", handleInteraction);

    return () => {
      c.removeEventListener("mousemove", handleInteraction);
      c.removeEventListener("touchstart", handleInteraction);
      if (hideTimeout.current) clearTimeout(hideTimeout.current);
    };
  }, [isLocked, controlsVisible, isPaused]);

  // Double-tap/click logic (re-using the previous logic)
  useEffect(() => {
    const container = containerRef.current;
    // ... (logic remains the same) ...
  }, [controlsVisible, isLocked]);

  // --- Render ---

  return (
    <div
      className={`vp-container ${isLocked ? "locked" : ""}`}
      ref={containerRef}
      // FIX: Single click handler on the container for when it's unlocked
      onClick={() => {
        if (isLocked) {
          // If locked, a single click simply makes the lock button visible temporarily
          setControlsVisible(true);
          // The useEffect handles the auto-hide timeout for the single lock icon
        } else {
          // If unlocked, a single click should trigger control visibility (like a mouse move/tap)
          showControlsTemporarily();
        }
      }}
    >
      {!videoSource && (
        <div className="no-video-message">
          <h3>Select a video from the list to begin playing.</h3>
        </div>
      )}
      {/* Video Wrapper (where video.js creates the player) */}
      <div className="video-wrapper" ref={videoWrapperRef} />
      {/* Controls are conditionally rendered based on video source */}
      {videoSource && (
        <>
          {/* 1. LOCK BUTTON: Always show when locked, or when controls are visible */}
          <button
            className={`lock-btn ${
              // This ensures the unlock button is visible when isLocked is true,
              // regardless of whether controlsVisible is true or false.
              controlsVisible || isLocked ? "show" : ""
            }  ${isLocked ? "active" : ""}`}
            onClick={toggleLock}
            title={isLocked ? "Unlock Controls" : "Lock Controls"}
          >
            {isLocked ? "🔒" : "🔓"}
          </button>

          {/* BRIGHTNESS CONTROL: Controls hidden if locked */}
          {!isLocked && (
            <div
              className={`left-vertical-volume ${
                controlsVisible ? "show" : ""
              }`}
            >
              <div className="top-icon">☀️</div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={brightness}
                onChange={(e) => {
                  setBrightness(e.target.value);
                  videoWrapperRef.current.style.filter = `brightness(${
                    0.5 + Number(e.target.value)
                  })`;
                }}
                orient="vertical"
              />
            </div>
          )}

          {/* VOLUME CONTROL: Controls hidden if locked */}
          {!isLocked && (
            <div
              className={`right-vertical-brightness ${
                controlsVisible ? "show" : ""
              }`}
            >
              <div className="top-icon">🔊</div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={(e) => onVolumeChange(e.target.value)}
                orient="vertical"
              />
            </div>
          )}

          {/* CENTER CONTROLS: Controls hidden if locked */}
          {!isLocked && (
            <div className={`center-controls ${controlsVisible ? "show" : ""}`}>
              {/* Previous Button (New) */}
              <button
                className="skip-btn"
                onClick={goToPrevious}
                disabled={!canGoPrevious}
                title="Previous Video"
              >
                ⏮
              </button>

              <button
                className="skip-btn"
                onClick={() =>
                  playerRef.current.currentTime(Math.max(0, current - 10))
                }
                title="Rewind 10s"
              >
                ⟲ 10s
              </button>

              <button className="play-center" onClick={togglePlay}>
                {isPaused ? "►" : "❚❚"}
              </button>

              <button
                className="skip-btn"
                onClick={() =>
                  playerRef.current.currentTime(
                    Math.min(duration, current + 10)
                  )
                }
                title="Forward 10s"
              >
                ⟳ 10s
              </button>

              {/* Next Button (New) */}
              <button
                className="skip-btn"
                onClick={goToNext}
                disabled={!canGoNext}
                title="Next Video"
              >
                ⏭
              </button>
            </div>
          )}

          {/* BOTTOM CONTROLS (Hidden if locked) */}
          {!isLocked && (
            <div
              className={`v-controls ${controlsVisible ? "visible" : "hidden"}`}
            >
              <div className="left">
                <div
                  className={`play-small ${current === 0 ? "hidden-init" : ""}`}
                  onClick={togglePlay}
                  aria-hidden
                >
                  {isPaused ? "►" : "❚❚"}
                </div>
                <div className="time current">{fmt(current)}</div>
              </div>

              <div className="seek-wrap">
                <input
                  className="seek"
                  type="range"
                  min={0}
                  max={Math.max(1, duration)}
                  step="0.1"
                  value={current}
                  onMouseDown={onSeekStart}
                  onTouchStart={onSeekStart}
                  onChange={(e) => onSeekChange(e.target.value)}
                  onMouseUp={(e) => onSeekEnd(e.target.value)}
                  onTouchEnd={(e) => onSeekEnd(e.target.value)}
                />
              </div>

              <div className="right">
                <div className="time total">{fmt(duration)}</div>

                <div className="speed-wrapper">
                  <div className="speed-container">
                    <button
                      className="speed-btn"
                      onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                    >
                      {playbackRate}x
                    </button>

                    {showSpeedMenu && (
                      <div className="speed-popup">
                        <div className="speed-box">
                          {[0.5, 1, 1.25, 1.5, 2].map((rate) => (
                            <div
                              key={rate}
                              className={`speed-item ${
                                rate === playbackRate ? "active" : ""
                              }`}
                              onClick={() => {
                                changeRate(rate);
                                setShowSpeedMenu(false);
                              }}
                            >
                              {rate}x
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  className="icon-btn"
                  onClick={toggleFullscreen}
                  title="Fullscreen"
                >
                  ⛶
                </button>

                <button
                  className="icon-btn"
                  onClick={togglePiP}
                  title="Picture in Picture"
                >
                  {isPiP ? "⤧" : "⧉"}
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
