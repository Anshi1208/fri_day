import React, { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";

const IMAGE_AD_DURATION = 5;

const isImage = (u) => /\.(jpg|jpeg|png|gif|webp)$/i.test(u);
const isVideo = (u) => /\.(mp4|mov|webm|mkv)$/i.test(u);

const fmt = (s = 0) =>
  !isFinite(s)
    ? "00:00"
    : `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(
        Math.floor(s % 60)
      ).padStart(2, "0")}`;

export default function VideoPlayer({
  videoSource,
  videos,
  setSelectedVideoUrl,
  ads,
  intervalMin,
}) {
  const container = useRef(null);
  const wrap = useRef(null);
  const main = useRef(null);
  const ad = useRef(null);
  const adContainer = useRef(null);

  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [paused, setPaused] = useState(true);
  const [rate, setRate] = useState(1);
  const [vol, setVol] = useState(1);
  const [visible, setVisible] = useState(true);
  const [locked, setLocked] = useState(false);
  const [bright, setBright] = useState(0.5);
  const [showSpeed, setShowSpeed] = useState(false);
  const [pip, setPip] = useState(false);
  const [adPlaying, setAdPlaying] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
const hasResumed = useRef(false);

  const hideT = useRef(null);
  const nextAdTime = useRef(null);
  const triggering = useRef(false);
  const imageAdTimer = useRef(null);
  const adShownCount = useRef(0);


  const showControls = () => {
    if (locked) return;
    clearTimeout(hideT.current);
    setVisible(true);
    if (!adPlaying && !paused) {
      hideT.current = setTimeout(() => setVisible(false), 3000);
    }
  };

  const changeRate = (r) => {
    if (!main.current) return;
    main.current.playbackRate(r);
    setRate(r);
    setShowSpeed(false);
  };

const toggleFS = async () => {
  const el = container.current;
  if (!el) return;

  try {
    if (!document.fullscreenElement) {
      // ENTER FULLSCREEN
      await el.requestFullscreen();
      setIsFullscreen(true);

      // Lock orientation to landscape (mobile)
      if (screen.orientation?.lock) {
        try {
          await screen.orientation.lock("landscape");
        } catch (e) {
          console.warn("Orientation lock failed:", e);
        }
      }
    } else {
      // EXIT FULLSCREEN
      await document.exitFullscreen();
      setIsFullscreen(false);

      // Unlock orientation
      if (screen.orientation?.unlock) {
        try {
          screen.orientation.unlock();
        } catch (e) {
          console.warn("Orientation unlock failed:", e);
        }
      }
    }
  } catch (err) {
    console.warn("Fullscreen error:", err);
  }
};

const RESUME_KEY = "last_video_resume";

const saveResume = (src, time) => {
  localStorage.setItem(RESUME_KEY, JSON.stringify({ src, time }));
};

const getResume = (src) => {
  const data = JSON.parse(localStorage.getItem(RESUME_KEY) || "{}");
  return data.src === src ? data.time : 0;
};

const clearResume = () => {
  localStorage.removeItem(RESUME_KEY);
};



  const togglePiP = async () => {
    const v = main.current?.tech()?.el();
    if (!v) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPip(false);
      } else {
        await v.requestPictureInPicture();
        setPip(true);
      }
    } catch (err) {
      console.warn("PiP failed:", err);
    }
  };

  const currentVideoIndex =
    videos.length > 0 ? videos.findIndex((v) => v.url === videoSource) : -1;

  const canGoNext = videos.length > 1;
  const canGoPrevious = videos.length > 1;

  const goToNext = () => {
    if (!canGoNext) return;
    const nextIndex = (currentVideoIndex + 1) % videos.length;
    setSelectedVideoUrl(videos[nextIndex].url);
  };
const handleVideoDoubleClick = () => {
  if (!adPlaying) {
    toggleFS();
  }
};

  const goToPrevious = () => {
    if (!canGoPrevious) return;
    const prevIndex =
      currentVideoIndex - 1 < 0 ? videos.length - 1 : currentVideoIndex - 1;
    setSelectedVideoUrl(videos[prevIndex].url);
  };

  const startAd = () => {
    console.log("📱 UA:", navigator.userAgent);

    console.log("🚀 startAd called", {
      adPlaying,
      triggering: triggering.current,
      adsLength: ads.length,
    });
    if (!ads.length || adPlaying || triggering.current) return;

    const url = ads[Math.floor(Math.random() * ads.length)];
    const p = main.current;
    if (!url || !p) return;
    
    console.log("🎯 Ad selected:", url, {
      isImage: isImage(url),
      isVideo: isVideo(url),
    });

    const resumeTime = p.currentTime();

    p.pause();
    triggering.current = true;
    setAdPlaying(true);
    setPaused(true);

    if (wrap.current) wrap.current.style.visibility = "hidden";

    const adDiv = document.createElement("div");
    adDiv.className = "ad-overlay";
    container.current.appendChild(adDiv);
    adContainer.current = adDiv;

    const endAd = () => {
      if (imageAdTimer.current) {
        clearTimeout(imageAdTimer.current);
        imageAdTimer.current = null;
      }

      if (ad.current) {
        ad.current.dispose();
        ad.current = null;
      }

      if (adContainer.current) {
        adContainer.current.remove();
        adContainer.current = null;
      }

      if (wrap.current) {
        wrap.current.style.visibility = "visible";
      }

      p.currentTime(resumeTime);

      setTimeout(() => {
        p.play();
        setAdPlaying(false);
        setPaused(false);
        triggering.current = false;

      const intervalSec = intervalMin * 60;
      adShownCount.current += 1;
      nextAdTime.current += intervalSec;


        console.log("📅 Next ad at:", nextAdTime.current, "seconds");
      }, 100);
    };

    if (isImage(url)) {
      const img = document.createElement("img");

      img.className = "ad-image";
      img.src = url;
      img.onload = () => console.log("🖼 Image ad loaded");

      img.onerror = () => {
        endAd();
      };
      adDiv.appendChild(img);
      imageAdTimer.current = setTimeout(endAd, IMAGE_AD_DURATION * 1000);
      return;
    }

    if (isVideo(url)) {
      const vid = document.createElement("video");
      vid.className = "video-js vjs-default-skin ad-video";
      vid.setAttribute("playsinline", "true");
      vid.setAttribute("webkit-playsinline", "true");
      adDiv.appendChild(vid);

      const adPlayer = videojs(vid, {
        controls: false,
        autoplay: true,
        preload: "auto",
        muted: true,
        sources: [{ src: url, type: "video/mp4" }],
      });

      ad.current = adPlayer;
      adPlayer.ready(() => {
        console.log("🎬 Ad player ready");

        const playPromise = adPlayer.play();
        if (playPromise) {
          playPromise
            .then(() => console.log("▶️ Ad play started"))
            .catch((err) => console.error("⛔ Ad play blocked", err));
        }
      });

      adPlayer.on("error", (err) => {
        console.error("❌ Ad error:", err);
        endAd();
      });
      adPlayer.on("ended", endAd);
    }
    
  };
  useEffect(() => {
    const onFsChange = () => {
      const fs = !!document.fullscreenElement;
      setIsFullscreen(fs);

      // Unlock orientation when user exits fullscreen manually
      if (!fs && screen.orientation?.unlock) {
        try {
          screen.orientation.unlock();
        } catch { /* empty */ }
      }
    };

    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  // Main video player setup
  useEffect(() => {

    if (!videoSource) {
      main.current?.dispose();
      if (wrap.current) wrap.current.innerHTML = "";
      return;
    }

    main.current?.dispose();
    if (wrap.current) wrap.current.innerHTML = "";

    if (isImage(videoSource)) {
      const img = document.createElement("img");
      img.src = videoSource;
      img.style.cssText = "width:100%;height:100%;object-fit:contain;";
      wrap.current.appendChild(img);
      return;
    }

    const el = document.createElement("video");
    el.className = "video-js vjs-default-skin";
    el.setAttribute("playsinline", "");
    el.setAttribute("webkit-playsinline", "");
    el.style.cssText = "width:100%;height:100%;object-fit:contain;";
    wrap.current.appendChild(el);
    hasResumed.current = false;


    const player = videojs(el, {
      controls: false,
      preload: "auto",
      autoplay: false,
      sources: [{ src: videoSource, type: getVideoType(videoSource) }],
      playbackRates: [0.5, 1, 1.25, 1.5, 2],
    });

    main.current = player;
    setVol(player.volume());
    setPaused(true);

  player.on("loadedmetadata", () => {
   setDuration(player.duration());
    const intervalSec = intervalMin * 60;
    adShownCount.current = 0;
    nextAdTime.current = intervalSec;
  });


    player.on("timeupdate", () => {
      if (adPlaying || triggering.current) return;

      const t = player.currentTime();
      setCurrent(t);

      saveResume(videoSource, t);

      // STRICT fixed interval
      if (t >= nextAdTime.current) {
        startAd();
      }
    });

    // CRITICAL FIX: Add play event listener
 player.on("play", () => {
   if (!hasResumed.current) {
     const resumeTime = getResume(videoSource);
     const dur = player.duration();

     if (resumeTime > 2 && resumeTime < dur - 2) {
       player.currentTime(resumeTime);

       // IMPORTANT: shift ad timer forward
       const intervalSec = intervalMin * 60;
       nextAdTime.current = Math.ceil(resumeTime / intervalSec) * intervalSec;
     }

     hasResumed.current = true;
   }

   setPaused(false);
 });



    player.on("pause", () => {
      if (!adPlaying) setPaused(true);
    });

    player.on("volumechange", () => setVol(player.volume()));

  player.on("ended", () => {
    clearResume(videoSource);

    if (document.fullscreenElement) {
      toggleFS();
    }

    goToNext();
  });
    


    return () => {
      player.dispose();
    };
  }, [videoSource, intervalMin, ads]);

  const togglePlay = async () => {
    if (locked || adPlaying) return;
    const p = main.current;
    if (!p) return;

    if (p.paused()) {
      try {
        await p.play();
      } catch (err) {
        console.error("Play failed:", err);
      }
    } else {
      p.pause();
    }

    showControls();
  };

  const seek = (v) => {
    if (locked || adPlaying || !main.current) return;

    setCurrent(v);
    main.current.currentTime(v);

    const intervalSec = intervalMin * 60;
    adShownCount.current = Math.floor(v / intervalSec);
    nextAdTime.current = (adShownCount.current + 1) * intervalSec;
  };

  const getVideoType = (url) => {
    if (url.endsWith(".webm")) return "video/webm";
    if (url.endsWith(".mp4")) return "video/mp4";
    if (url.endsWith(".mov")) return "video/quicktime";
    return "video/mp4";
  };

  const handleVolumeChange = (e) => {
    if (!main.current) return;
    const newVol = parseFloat(e.target.value);
    main.current.volume(newVol);
    setVol(newVol);
  };

  return (
    <div
      className={`vp-container ${locked ? "locked" : ""}`}
      ref={container}
      onClick={showControls}
      onMouseMove={showControls}
      onDoubleClick={handleVideoDoubleClick} // ✅ ADD THIS
    >
      <div
        ref={wrap}
        className="video-wrapper"
        style={{
          filter: `brightness(${0.5 + Number(bright)})`,
        }}
      />

      {videoSource && (
        <>
          <button
            onClick={() => setLocked((x) => !x)}
            className={`lock-btn ${visible ? "show" : ""}`}
          >
            {locked ? "🔒" : "🔓"}
          </button>

          {!locked && !adPlaying && (
            <div
              className={`right-vertical-brightness ${visible ? "show" : ""}`}
            >
              <div className="top-icon">☀️</div>
              <input
                type="range"
                className="mobile-vertical-slider brightness-slider"
                min="0"
                max="1"
                step="0.01"
                value={bright}
                onChange={(e) => setBright(e.target.value)}
              />
            </div>
          )}

          {!locked && !adPlaying && (
            <div className={`left-vertical-volume ${visible ? "show" : ""}`}>
              <div className="top-icon">🔊</div>
              <input
                type="range"
                className="mobile-vertical-slider volume-slider"
                min="0"
                max="1"
                step="0.01"
                value={vol}
                onChange={handleVolumeChange}
              />
            </div>
          )}

          {!locked && !adPlaying && (
            <div className={`center-controls ${visible ? "show" : ""}`}>
              <button
                onClick={() => seek(Math.max(0, current - 10))}
                className="jump-btn"
              >
                <div className="jump-icon">⟲</div>
              </button>
              <button onClick={togglePlay} className="play-main-btn">
                {paused ? "►" : "❚❚"}
              </button>
              <button
                onClick={() => seek(Math.min(duration, current + 10))}
                className="jump-btn"
              >
                <div className="jump-icon">⟳</div>
              </button>
            </div>
          )}

          {!locked && !adPlaying && (
            <div className={`bottom-controls ${visible ? "show" : ""}`}>
              <div className="new-bottom">
                <input
                  type="range"
                  className="seekbar-full"
                  min={0}
                  max={duration || 100}
                  step="0.1"
                  value={current}
                  onChange={(e) => seek(Number(e.target.value))}
                  style={{
                    "--seek-progress": `${(current / duration) * 100}%`,
                  }}
                />

                <div className="controls-row">
                  <div className="controls-left">
                    <button
                      onClick={goToPrevious}
                      disabled={!canGoPrevious}
                      className="control-btn"
                    >
                      ⏮
                    </button>
                    <button onClick={togglePlay} className="control-btn">
                      {paused ? "►" : "❚❚"}
                    </button>
                    <button
                      onClick={goToNext}
                      disabled={!canGoNext}
                      className="control-btn"
                    >
                      ⏭
                    </button>
                    <span className="time-display">
                      {fmt(current)} / {fmt(duration)}
                    </span>
                  </div>

                  <div className="controls-right">
                    <div className="speed-menu">
                      <button
                        onClick={() => setShowSpeed(!showSpeed)}
                        className="control-btn"
                      >
                        {rate}x
                      </button>
                      {showSpeed && (
                        <div className="speed-dropdown">
                          {[0.5, 1, 1.25, 1.5, 2].map((r) => (
                            <div
                              key={r}
                              onClick={() => changeRate(r)}
                              className={`speed-option ${
                                rate === r ? "active" : ""
                              }`}
                            >
                              {r}x
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <button onClick={togglePiP} className="control-btn">
                      {pip ? "⧉" : "⤧"}
                    </button>
                    <button onClick={toggleFS} className="control-btn">
                      ⛶
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
