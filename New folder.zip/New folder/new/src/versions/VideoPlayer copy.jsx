import React, { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";
import "./index.css"; // save the CSS below into this file
import videoFile from "/yaar-ka-sataya-hua-hai.mp4";

const fmt = (s = 0) => {
  // ... (fmt function remains the same)
  if (!isFinite(s)) return "00:00";
  const mm = Math.floor(s / 60)
    .toString()
    .padStart(2, "0");
  const ss = Math.floor(s % 60)
    .toString()
    .padStart(2, "0");
  return `${mm}:${ss}`;
};

export default function VideoPlayer() {
  const containerRef = useRef(null);
  const videoWrapperRef = useRef(null);
  const playerRef = useRef(null);
  const [brightness, setBrightness] = useState(0.5);
  const [isPaused, setIsPaused] = useState(true);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [isPiP, setIsPiP] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const hideTimeout = useRef(null);
  const seekingRef = useRef(false); // Initialize video.js player

  useEffect(() => {
    // ... (video.js initialization remains the same)
    if (playerRef.current) return;

    const el = document.createElement("video-js");
    el.className = "vjs-tech";
    if (videoWrapperRef.current) videoWrapperRef.current.appendChild(el);

    playerRef.current = videojs(el, {
      controls: false, // we use our own minimal controls
      preload: "auto",
      fluid: false,
      autoplay: false,
      sources: [{ src: videoFile, type: "video/mp4" }],
      playbackRates: [0.5, 1, 1.25, 1.5, 2],
      textTrackSettings: false,
    });

    const p = playerRef.current; // update duration when metadata loads

    p.on("loadedmetadata", () => {
      setDuration(p.duration() || 0);
      setCurrent(p.currentTime() || 0);
    }); // update time while playing

    p.on("timeupdate", () => {
      if (!seekingRef.current) setCurrent(p.currentTime() || 0);
    });

    p.on("play", () => {
      setIsPaused(false);
      showControlsTemporarily();
    });
    p.on("pause", () => {
      setIsPaused(true);
      showControls(true);
    });

    p.on("volumechange", () => {
      setVolume(p.volume());
    });

    p.on("enterpictureinpicture", () => setIsPiP(true));
    p.on("leavepictureinpicture", () => setIsPiP(false)); // clean up

    return () => {
      if (hideTimeout.current) clearTimeout(hideTimeout.current);
      if (playerRef.current) {
        playerRef.current.dispose();
        playerRef.current = null;
      }
    }; // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // show controls & set hide timer

  const showControls = (force = false) => {
    // ... (showControls function remains the same)
    if (hideTimeout.current) {
      clearTimeout(hideTimeout.current);
      hideTimeout.current = null;
    }
    setControlsVisible(true);

    const p = playerRef.current;
    if (!p) return;

    if (!p.paused() && !force) {
      hideTimeout.current = setTimeout(() => setControlsVisible(false), 3000);
    }
  };

  const showControlsTemporarily = () => showControls(false); // clicking/tapping container toggles controls (single tap) or seeks (double)

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let dblTimer = null;
    const onPointer = (e) => {
      // 🛑 THE CRUCIAL FIX IS HERE:
      // if clicking on any controls (bottom bar, vertical sliders, or center controls/play buttons), ignore
      if (
        e.target.closest(".v-controls") ||
        e.target.closest(".left-vertical-volume") ||
        e.target.closest(".right-vertical-brightness") ||
        e.target.closest(".center-controls") || // **Check if click is on the center controls block**
        e.target.closest(".center-play")
      ) {
        // **Check if click is on the big center play button**
        return;
      }

      if (!dblTimer) {
        // single tap: toggle controls
        dblTimer = setTimeout(() => {
          dblTimer = null; // show controls if hidden; if visible and paused -> play
          if (!controlsVisible) {
            showControls(true);
          } else {
            // toggle play/pause on single tap when controls shown
            // but we have big center button too, so just show controls
            showControls(true);
          }
        }, 250);
      } else {
        // double tap -> seek
        clearTimeout(dblTimer);
        dblTimer = null;
        const rect = container.getBoundingClientRect();
        const x = e.touches ? e.touches[0].clientX : e.clientX;
        if (x - rect.left < rect.width / 2) {
          // left half: backward 10s
          playerRef.current.currentTime(
            Math.max(0, playerRef.current.currentTime() - 10)
          );
        } else {
          // right half: forward 10s
          playerRef.current.currentTime(
            Math.min(
              playerRef.current.duration(),
              playerRef.current.currentTime() + 10
            )
          );
        }
        showControls(true);
      }
    };

    container.addEventListener("mousedown", onPointer);
    container.addEventListener("touchstart", onPointer, { passive: false });

    return () => {
      container.removeEventListener("mousedown", onPointer);
      container.removeEventListener("touchstart", onPointer);
    };
  }, [controlsVisible]); // center play/pause toggle

  const togglePlay = (e) => {
    // 🛑 Stop propagation is already here, but let's confirm it's on the element itself:
    e?.stopPropagation();
    if (!playerRef.current) return;
    if (playerRef.current.paused()) playerRef.current.play();
    else playerRef.current.pause();
    showControls(true);
  };

  // seek via slider
  const onSeekChange = (value) => {
    if (!playerRef.current) return;
    seekingRef.current = true;
    setCurrent(Number(value));
  };
  const onSeekStart = () => {
    seekingRef.current = true;
    if (hideTimeout.current) clearTimeout(hideTimeout.current);
  };
  const onSeekEnd = (value) => {
    if (!playerRef.current) return;
    playerRef.current.currentTime(Number(value));
    seekingRef.current = false;
    showControls(true);
  };

  // playback rate
  const changeRate = (r) => {
    if (!playerRef.current) return;
    playerRef.current.playbackRate(r);
    setPlaybackRate(r);
    showControls(true);
  };

  // fullscreen
  const toggleFullscreen = async () => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await el.requestFullscreen().catch(() => {});
    }
  };

  // PiP
  const togglePiP = async () => {
    const p = playerRef.current;
    if (!p) return;
    try {
      if (isPiP) await p.exitPictureInPicture();
      else await p.requestPictureInPicture();
    } catch (err) {
      console.warn("PiP not supported:", err);
    }
  };

  // volume small slider
  const onVolumeChange = (v) => {
    if (!playerRef.current) return;
    playerRef.current.volume(Number(v));
    setVolume(Number(v));
    showControls(true);
  };

  // show controls whenever mouse moves over container
  useEffect(() => {
    const c = containerRef.current;
    if (!c) return;
    let mvTimer = null;
    const onMove = () => {
      showControls(false);
      if (mvTimer) clearTimeout(mvTimer);
      mvTimer = setTimeout(() => {
        if (!playerRef.current?.paused()) setControlsVisible(false);
      }, 2500);
    };
    c.addEventListener("mousemove", onMove);
    c.addEventListener("touchstart", onMove, { passive: true });
    return () => {
      c.removeEventListener("mousemove", onMove);
      c.removeEventListener("touchstart", onMove);
      if (mvTimer) clearTimeout(mvTimer);
    };
  }, []);

  // update the duration/current when state changes (keeps UI synced)
  useEffect(() => {
    if (!playerRef.current) return;
    // ensure duration is set
    if (!duration && playerRef.current.duration())
      setDuration(playerRef.current.duration());
  }, [duration]);

  return (
    <div className="vp-container" ref={containerRef}>
      <div className="video-wrapper" ref={videoWrapperRef} />

      {/* LEFT vertical volume */}
      <div className={`left-vertical-volume ${controlsVisible ? "show" : ""}`}>
        <div className="top-icon">🔊</div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={(e) => onVolumeChange(e.target.value)}
          orient="vertical"
        />
      </div>

      {/* RIGHT vertical brightness */}
      <div
        className={`right-vertical-brightness ${controlsVisible ? "show" : ""}`}
      >
        <div className="top-icon">☀️</div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={brightness}
          onChange={(e) => {
            setBrightness(e.target.value);
            videoWrapperRef.current.style.filter = `brightness(${
              0.5 + Number(e.target.value)
            })`;
          }}
          orient="vertical"
        />
      </div>

      {/* Center Forward/Backward Controls */}
      <div className={`center-controls ${controlsVisible ? "show" : ""}`}>
        <button
          className="skip-btn"
          onClick={() =>
            playerRef.current.currentTime(Math.max(0, current - 10))
          }
        >
          ⟲ 10s
        </button>
        <button className="play-center" onClick={togglePlay}>
          {isPaused ? "►" : "❚❚"}
        </button>
        <button
          className="skip-btn"
          onClick={() =>
            playerRef.current.currentTime(Math.min(duration, current + 10))
          }
        >
          ⟳ 10s
        </button>
      </div>

      {/* Center big play/pause overlay */}
      <button
        className={`center-play ${isPaused ? "show" : ""}`}
        onClick={togglePlay}
        aria-label="Play/Pause"
      >
        {isPaused ? "►" : "❚❚"}
      </button>

      {/* Bottom control bar */}
      <div className={`v-controls ${controlsVisible ? "visible" : "hidden"}`}>
        <div className="left">
          <div
            className={`play-small ${current === 0 ? "hidden-init" : ""}`}
            onClick={togglePlay}
            aria-hidden
          >
            {isPaused ? "►" : "❚❚"}
          </div>

          <div className="time current">{fmt(current)}</div>
        </div>

        <div className="seek-wrap">
          <input
            className="seek"
            type="range"
            min={0}
            max={Math.max(1, duration)}
            step="0.1"
            value={current}
            onMouseDown={onSeekStart}
            onTouchStart={onSeekStart}
            onChange={(e) => onSeekChange(e.target.value)}
            onMouseUp={(e) => onSeekEnd(e.target.value)}
            onTouchEnd={(e) => onSeekEnd(e.target.value)}
          />
        </div>

        <div className="right">
          <div className="time total">{fmt(duration)}</div>

          <select
            className="speed-select small"
            value={playbackRate}
            onChange={(e) => changeRate(Number(e.target.value))}
            title="Playback speed"
          >
            <option value="0.5">0.5x</option>
            <option value="1">1x</option>
            <option value="1.25">1.25x</option>
            <option value="1.5">1.5x</option>
            <option value="2">2x</option>
          </select>

          <button
            className="icon-btn"
            onClick={toggleFullscreen}
            title="Fullscreen"
          >
            ⛶
          </button>
          <button
            className="icon-btn"
            onClick={togglePiP}
            title="Picture in Picture"
          >
            {isPiP ? "⤧" : "⧉"}
          </button>
        </div>
      </div>
    </div>
  );
}
