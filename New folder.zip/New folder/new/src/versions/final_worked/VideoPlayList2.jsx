import React, { useState, useEffect, useCallback } from "react";
import VideoPlayer from "./VideoPlayer1";
import "./index.css";

const ADS_API = "http://localhost:5000/api/ads";
const INTERVAL_API = "http://localhost:5000/api/ad-interval";

const isImage = (u) => /\.(jpg|jpeg|png|gif|webp)$/i.test(u);
const isVideo = (u) => /\.(mp4|mov|webm|mkv)$/i.test(u);

// Fetch videos from public/videos.json
const fetchVideosFromJSON = () => {
  return new Promise((resolve, reject) => {
    fetch("/videos.json")
      .then((res) => res.json())
      .then((data) => resolve(data))
      .catch((err) => reject(err));
  });
};

export default function VideoPlaylist() {
  const [videos, setVideos] = useState([]);
  const [selectedVideoUrl, setSelectedVideoUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Ad-related state
  const [ads, setAds] = useState([]);
  const [intervalMin, setIntervalMin] = useState(1);

  // Fetch videos
  useEffect(() => {
    setIsLoading(true);
    fetchVideosFromJSON()
      .then((data) => {
        setVideos(data);
        if (data.length > 0) {
          setSelectedVideoUrl(data[0].url);
        }
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Error loading videos:", err);
        setIsLoading(false);
      });
  }, []);

  // Fetch ads and interval
  useEffect(() => {
    // Fetch ads
    fetch(ADS_API)
      .then((r) => r.json())
      .then((d) => {
        const allAds = Array.isArray(d)
          ? d.filter((url) => isImage(url) || isVideo(url))
          : [];
        console.log("✅ Loaded", allAds.length, "ads");
        setAds(allAds);
      })
      .catch((err) => console.error("❌ Error fetching ads:", err));

    // Fetch ad interval
    fetch(INTERVAL_API)
      .then((r) => r.json())
      .then((d) => {
        if (typeof d?.minutes === "number") {
          console.log("✅ Ad interval:", d.minutes, "minute(s)");
          setIntervalMin(d.minutes);
        }
      })
      .catch((err) => console.error("❌ Error reading interval:", err));
  }, []);

  const handleVideoSelect = (url) => {
    
    setSelectedVideoUrl(url);
  };

  const currentVideoIndex = videos.findIndex((v) => v.url === selectedVideoUrl);

 

  const currentVideoTitle = videos.find(
    (v) => v.url === selectedVideoUrl
  )?.title;

  return (
    <div className="video-app-container">
      {/* 1. PLAYLIST SECTION - Now on top */}
      <div className="playlist-section-top">
        <h3>Now Playing: {currentVideoTitle || "N/A"}</h3>
        <p>
          Ad Interval: {intervalMin} minute(s) | Total Ads: {ads.length}
        </p>
        {isLoading ? (
          <p>Loading videos...</p>
        ) : videos.length === 0 ? (
          <p>
            No videos found. Check your VIDEO_FILES list and public folder
            setup.
          </p>
        ) : (
          <ul className="video-list-horizontal">
            {videos.map((video) => (
              <li
                key={video.id}
                className={`video-item ${
                  selectedVideoUrl === video.url ? "active" : ""
                }`}
                onClick={() => handleVideoSelect(video.url)}
              >
                {video.title}{" "}
                {selectedVideoUrl === video.url ? " (Playing)" : ""}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* 2. VIDEO PLAYER SECTION - Now below the playlist */}
      <div className="player-section-bottom">
        <VideoPlayer
          videoSource={selectedVideoUrl}
          videos={videos}
          setSelectedVideoUrl={setSelectedVideoUrl}
          ads={ads}
          intervalMin={intervalMin}
        />
      </div>
    </div>
  );
}
