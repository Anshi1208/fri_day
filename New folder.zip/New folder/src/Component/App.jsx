/* eslint-disable no-unused-vars */
// import { useState } from 'react'
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Marquee from './Marquee';
import Banner from './Banner';
import Sliders from './Sliders';
import Footer  from './Footer';
import '../Css/index.css'


// import UDPReceiver from './UDPReceiver'
// ;<UDPReceiver />
function App() {


  return (
    <>
      <div>
       <Marquee  onContextMenu={(e) => e.preventDefault()}/>
       <Banner  onContextMenu={(e) => e.preventDefault()}/>
       <Sliders  onContextMenu={(e) => e.preventDefault()}/>
       <Footer onContextMenu={(e) => e.preventDefault()}/>
    </div>
    </>
  )
}

export default App
