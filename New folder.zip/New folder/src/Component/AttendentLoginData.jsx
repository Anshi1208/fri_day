import { useState, useEffect } from 'react'
import MarqueeWithBack from '../Component/MarqueeWithBack'
import { useNavigate } from 'react-router-dom';
import Banner from '../Component/Banner'
import Footer from '../Component/Footer'
import '../Css/AttendentLoginData.css'
import useLogin from '@api/useLogin'
import { decryptData } from '@api/cryptoUtils'

const AttendentLoginData = () => {
  const [status, setStatus] = useState('both')
  const [selectedDate, setSelectedDate] = useState('All Dates') // New state for date filter All Dates
  const [existingRequests, setExistingRequests] = useState([])
  const [filteredRequests, setFilteredRequests] = useState([])
  const [popupMessage, setPopupMessage] = useState('')
  const [popupType, setPopupType] = useState('') // 'success' or 'error'
  const [showPopup, setShowPopup] = useState(false) // Control visibility
  const [data, setData] = useState(null)
  const {token}=useLogin()
  const navigate = useNavigate();

    // Pagination states

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;
 

    // Fetch media list from the API
    useEffect(() => {
      // Check if the user is logged in by verifying the session
    const isLoggedIn = sessionStorage.getItem('isLoggedIn');
    const expirationTime = sessionStorage.getItem('expirationTime');



    // Redirect to login page if session doesn't exist or has expired
    if (!isLoggedIn || !expirationTime || new Date().getTime() > parseInt(expirationTime)) {
      navigate('/Attendent-Login');
    } 


      if (token) {
        fetch(`/api/data/`, {
          headers: {
            Authorization: `Bearer ${token}` // Include the token in the request headers
          }
        })
          .then((response) => {
            if (!response.ok) {
              throw new Error('Failed to fetch data')
            }
            return response.json()
          })
          .then((data) => {
             // Decrypt the fields that were encrypted
        const decryptedData = data.map((item) => ({
          ...item,
          pnr: decryptData(item.pnr),
          passengerName: decryptData(item.passengerName),
          contactNumber: decryptData(item.contactNumber),
          seatNumber: decryptData(item.seatNumber),
        }));

        setExistingRequests(decryptedData); // Set decrypted data
        setFilteredRequests(decryptedData); // Initially, show all decrypted data in filteredRequests
     })
          .catch((error) => {
            console.error('Fetch error:', error)
            setExistingRequests([])
          })

      }
    }, [token,data])
    
  // Function to format the date as DD-MM-YYYY
function formatDate(date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed in JS
  const year = date.getFullYear();
  return `${month}/${day}/${year}`;
}

// Function to format time in 24-hour format (HH:MM:SS)
function formatTime(date) {
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}


  const generateLast7Days = () => {
    const days = [];
    days.push('All Dates');
    
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const formattedDate =  formatDate(date)
      days.push(formattedDate);
    }
    return days;
  }
  

  const last7Days = generateLast7Days()


  const handleFilterChange = (e) => {
    const selectedStatus = e.target.value
    setStatus(selectedStatus)
    // Apply filtering based on status and date
    filterRequests(selectedStatus, selectedDate)
  }

  const handleDateChange = (e) => {
    const selectedDate = e.target.value
    setSelectedDate(selectedDate)
    // Apply filtering based on status and date
    filterRequests(status, selectedDate)
  }


  
  const filterRequests = (status, date) => {
    let filtered = existingRequests;
    // Filter by status
    if (status === 'open') {
      filtered = filtered.filter((req) => req.status.trim().toLowerCase() === 'open');
    } else if (status === 'close') {
      filtered = filtered.filter((req) => req.status.trim().toLowerCase() === 'close');
    }
  
    // Filter by date
    if (date !== 'All Dates') {
      filtered = filtered.filter((req) => req.date === date);
    }
  
    setFilteredRequests(filtered);
  }
  

  

  const handleActionTakenChange = (index, newAction) => {
    // console.log(index,newAction,request_id,)
    
    const updatedRequests = [...filteredRequests]
    // console.log(updatedRequests)
    updatedRequests[index].actionTaken = newAction
    setFilteredRequests(updatedRequests)
  }

  // Handle status change and update data on the json file 
  const handleStatusChange = (index, newStatus) => {
    // console.log(index,newStatus,request_id)
    // console.log(existingRequests)
    const requestToUpdate = existingRequests[index]

    // console.log(requestToUpdate)
    // Update the request's properties
    const updatedRequest = {
      ...requestToUpdate,
      status: newStatus,
      date: formatDate(new Date()), // Custom formatted current date
      time: formatTime(new Date()), // Custom formatted current time in 24-hour format
      actionTaken: requestToUpdate.actionTaken || '', // Ensure actionTaken is included
    }

    // Update existingRequests directly to show changes in the UI immediately
    const updatedRequests = [...existingRequests]
    updatedRequests[index] = updatedRequest

    setFilteredRequests(updatedRequests)
    setExistingRequests(updatedRequests) // Update the existing requests to show in table immediately

    // console.log(updatedRequests[index])
    // Update data on the json 
    fetch(`/api/data/${requestToUpdate.pnr}/${index}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updatedRequest),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to update data')
        }
        return response.json()
      })
      .then(() => {
        setPopupMessage('Status updated successfully!')
        setPopupType('success')
        setShowPopup(true)
      })
      .catch((error) => {
        console.error('Update error:', error)
        // Revert changes if there's an error
        setFilteredRequests(existingRequests)
        setPopupMessage('Failed to update status, please try again.')
        setPopupType('error')
        setShowPopup(true)
      })
  }



  const closePopup = () => {
    setShowPopup(false)
    setPopupMessage('')
    setPopupType('')
  }

  // Calculate the data to display for the current page
  const indexOfLastRequest = currentPage * itemsPerPage;
  const indexOfFirstRequest = indexOfLastRequest - itemsPerPage;
  const currentRequests = filteredRequests.slice(indexOfFirstRequest, indexOfLastRequest);
  // Pagination control functions
  const nextPage = () => {
    if (currentPage < Math.ceil(filteredRequests.length / itemsPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };


  return (
    <>
      <MarqueeWithBack />
      <Banner />
      <h1 className="attendent-title">Onboard Service Requests</h1>
      <div
        className="attendent-container"
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* Service Status Dropdown */}
        <div className="attendent-dropdown">
          <label className="attendent-dropdown-label" htmlFor="statusFilter">
            Service Status Sort:
          </label>
          <select
            id="statusFilter"
            value={status}
            onChange={handleFilterChange}
          >
            <option value="both">Both</option>
            <option value="open">Open</option>
            <option value="close">Close</option>
          </select>
        </div>

        {/* Date Filter Dropdown */}
        <div className="attendent-dropdown">
          <label className="attendent-dropdown-label" htmlFor="dateFilter">
            Date Filter:
          </label>
          <select
            id="dateFilter"
            value={selectedDate}
            onChange={handleDateChange}
          >
            {last7Days.map((day, index) => (
              <option key={index} value={day}>
                {day}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div
        className="attendent-table-container"
        onContextMenu={(e) => e.preventDefault()}
      >
        <table className="attendent-table">
          <thead>
            <tr>
              <th>S.No</th>
              <th>PNR</th>
              <th>Passenger Name</th>
              <th>Contact Number</th>
              <th>Seat Number</th>
              <th>Service Type</th>
              <th>Complaint</th>
              <th>Date</th>
              <th>Time</th>
              <th>Action Taken</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {currentRequests.length > 0 ? (
              currentRequests.map((request, index) => (
                <tr key={index}>
                  <td>{index + 1 + indexOfFirstRequest}</td>
                  <td>{request.pnr || "N/A"}</td>
                  <td>{request.passengerName || "N/A"}</td>
                  <td>{request.contactNumber || "N/A"}</td>
                  <td>{request.seatNumber || "N/A"}</td>
                  <td>{request.serviceType || "N/A"}</td>
                  <td>{request.complaint || "N/A"}</td>
                  <td>{request.date || "N/A"}</td>
                  <td>{request.time || "N/A"}</td>

                  <td>
                    {request.status.trim().toLowerCase() === "open" ? (
                      <input
                        type="text"
                        onChange={(e) =>
                          handleActionTakenChange(index, e.target.value)
                        }
                        placeholder="Write your action here"
                      />
                    ) : (
                      request.actionTaken
                    )}
                  </td>

                  <td>
                    {request.status.trim().toLowerCase() === "open" ? (
                      <select
                        className="attendent-dropdown-status"
                        value={request.status}
                        onChange={(e) =>
                          handleStatusChange(index, e.target.value)
                        }
                      >
                        <option value="open">Open</option>
                        <option value="close">Close</option>
                      </select>
                    ) : (
                      request.status
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="11">No Record found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <div
        className="pagination-controls"
        onContextMenu={(e) => e.preventDefault()}
      >
        <button onClick={prevPage} disabled={currentPage === 1}>
          Previous
        </button>
        <span>
          Page {currentPage} of{" "}
          {Math.ceil(filteredRequests.length / itemsPerPage)}
        </span>
        <button
          onClick={nextPage}
          disabled={
            currentPage === Math.ceil(filteredRequests.length / itemsPerPage)
          }
        >
          Next
        </button>
      </div>

      {/* Popup Notification */}
      {showPopup && (
        <div
          className="popup-overlay"
          onClick={closePopup}
          onContextMenu={(e) => e.preventDefault()}
        >
          <div className={`popup-notification ${popupType}`}>
            <p className="popup-message">{popupMessage}</p>
            <button onClick={closePopup}>OK</button>
          </div>
        </div>
      )}

      <Footer />
    </>
  );
}

export default AttendentLoginData
