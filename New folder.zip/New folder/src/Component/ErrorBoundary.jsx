/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { Component } from 'react';
import '../Css/ErrorBoundary.css';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Error caught in Error Boundary:', error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/'; // Assumes your main page is at the root URL
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-container">
          <div className="error-content">
            <h1 className="error-title">Oops! Something went wrong.</h1>
            <p className="error-message">Please reload the page or contact support.</p>
            <div className="error-actions">
              <button className="error-btn refresh-btn" onClick={this.handleReload}>🔄 Refresh</button>
              <button className="error-btn home-btn" onClick={this.handleGoHome}>🏠 Go to Main Page</button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
