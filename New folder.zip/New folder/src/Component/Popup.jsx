/* eslint-disable react/prop-types */
import { useEffect, useState } from 'react';
import '../Css/Popup.css'; // Importing CSS for the popup
import { io } from 'socket.io-client';

// Default empty functions to prevent errors if props are not provided
const Popup = ({ pauseMedia, resumeMedia, isUserPaused,exitFullscr, resumeAdMedia = () => {}, pauseAdMedia = () => {} }) => {
  const [isOpen, setIsOpen] = useState(false);
// Determine WebSocket server URL dynamically
// Get the server port from environment variables (default to 5000 if not set)
const SERVER_PORT = import.meta.env.VITE_SERVER_PORT || 5000;
const SERVER_HOST = import.meta.env.VITE_SERVER_HOST || "192.168.0.243"; // Replace with actual IP

const serverUrl2 = `http://${SERVER_HOST}:${SERVER_PORT}`;

let serverUrl;
  useEffect(() => {


    if (typeof window !== "undefined") {
      // Browser environment
      serverUrl = `${window.location.protocol}//${window.location.hostname}:${import.meta.env.VITE_SERVER_PORT}`;
    } else {
      // Node.js environment (set manually or use env variable)
      serverUrl = `${serverUrl2}`;  // Replace with actual server IP
    }

    // Dynamically construct WebSocket URL using window.location.host
    
    const socket = io(serverUrl, {
      transports: ["websocket"], // Ensure compatibility with mobile devices
    });


    socket.on('connect', () => {
      // console.log('WebSocket Connected:', socket.id);
      // console.log(`Connected to WebSocket server at ${serverUrl}`);
    });
  
  
    // Handle incoming UDP messages
    socket.on('udpData', (message) => {
      // let UdpIncomingMessage = message.muteStatus
      
      // Convert muteStatus to lowercase
       let UdpIncomingMessage = message.muteStatus.toLowerCase() === "mute" ? "close" : "open";

      // console.log("Received UDP message:", message);

      if (UdpIncomingMessage.includes('open')) {
        resumeAdMedia();
        // Only resume media playback if the user did not manually pause it
        if (!isUserPaused) {
          resumeMedia();
        } else {
          pauseMedia();
          exitFullscr()
        }
        setIsOpen(false); // Close the popup when 'open' message is received
      } else if (UdpIncomingMessage.includes('close')) {
        pauseAdMedia();
        exitFullscr()
        pauseMedia(); // Pause media playback
        setIsOpen(true); // Show the popup when 'close' message is received
      }
    });

      // Handle disconnection
      socket.on("disconnect", () => {
        console.log("Disconnected from WebSocket server");
      });

    // Clean up socket connection on component unmount
    return () => {
      socket.disconnect();
    };
  }, [pauseMedia, resumeMedia, isUserPaused, pauseAdMedia, resumeAdMedia]); // Removed serverIp dependency since it's not needed

  // If popup is not open, render nothing
  if (!isOpen) return null;

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <h2>PA in Progress.....</h2>
      </div>
    </div>
  );
};

export default Popup;
