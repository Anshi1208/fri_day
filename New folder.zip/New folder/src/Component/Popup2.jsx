/* eslint-disable react/prop-types */
import { useEffect, useState } from 'react';
import '../Css/Popup.css'; // Importing CSS for the popup

const Popup2 = ({pauseMedia, resumeMedia, isUserPaused }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [udpIncomingMessage, setUdpIncomingMessage] = useState(''); // Initialize as a string

  useEffect(() => {
    // Function to fetch UDP messages from the server
    const fetchMessages = async () => {
      try {
        const response = await fetch('/api/udp-messages'); // Replace with your server's API endpoint
        if (response.ok) {
          const data = await response.json();
          
          if (data && typeof data.muteStatus === "string") {
            const message = data.muteStatus.toLowerCase() === "mute" ? "close" : "open";
            setUdpIncomingMessage(message);
          } else {
            console.error("Unexpected API response:", data);
            setUdpIncomingMessage("open"); // Default value
          }
        } else {
          setUdpIncomingMessage("open");
        }
      } catch (err) {
        console.error("Error fetching messages:", err.message);
      }
    };

    // Polling interval to fetch messages every 2 seconds
    const interval = setInterval(fetchMessages, 2000);

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []); // Empty dependency array to prevent unnecessary re-renders

  useEffect(() => {
    // Handling the received message (open/close logic)
    if (udpIncomingMessage.includes('open')) {
       // Only resume media playback if the user did not manually pause it
       if (!isUserPaused) {
        resumeMedia();
      } else {
        pauseMedia();
      }
      setIsOpen(false); // Close the popup when 'open' message is received
    } else if (udpIncomingMessage.includes('close')) {
      pauseMedia(); // Pause media playback
      setIsOpen(true); // Show the popup when 'close' message is received
    }
  }, [udpIncomingMessage]); // Runs only when udpIncomingMessage changes

  // If the popup is not open, render nothing
  if (!isOpen) return null;

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <h2>PA in Progress.....</h2>
      </div>
    </div>
  );
};

export default Popup2;
