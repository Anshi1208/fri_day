import React, { useState, useEffect } from 'react';

const UDPReceiver = () => {
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Function to fetch UDP messages from the server
    const fetchMessages = async () => {

      try {
        const response = await fetch('/api/udp-messages'); // Replace with your server's public IP
        if (response.ok) {
          const data = await response.json();
          // console.log(data)
          setMessages(data[0]); // Update state with the messages received from the server
        } else {
            setMessages('CLOSE');
          setError('Failed to fetch messages');
        }
      } catch (err) {
        setError('Error fetching messages: ' + err.message);
      }
    };

    // Polling interval to fetch messages every 5 seconds
    const interval = setInterval(fetchMessages, 1000);

    // Cleanup on component unmount
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <h1>UDP Messages</h1>
      {error && <p>{error}</p>}

      <div>
        {messages.length > 0 ? (
              <p>{messages}</p>
        ) : (
          <p>No messages received yet...</p>
        )}
      </div>
    </div>
  );
};

export default UDPReceiver;
