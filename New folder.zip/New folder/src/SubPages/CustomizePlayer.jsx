import { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";
const BASE = import.meta.env.VITE_API_BASE || "http://localhost:5000";
const ADS_API = `${BASE}/api/ads`;
const INTERVAL_API = `${BASE}/api/ad-interval`;

const IMAGE_AD_DURATION = 5;
// ✅ FIXED: Keep original function signature, works correctly now
const LAST_SRC_KEY = "last_video_src";
const LAST_TIME_KEY = "last_video_time";

const isImage = (u) => /\.(jpg|jpeg|png|gif|webp)$/i.test(u);
const isVideo = (u) => /\.(mp4|mov|webm|mkv)$/i.test(u);

const fmt = (s = 0) =>
  !isFinite(s)
    ? "00:00"
    : `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(
        Math.floor(s % 60)
      ).padStart(2, "0")}`;

export default function CustomizePlayer({
  videoSource,
  goToNext,
  goToPrevious,
  canGoNext,
  canGoPrevious,
}) {
  const container = useRef(null);
  const wrap = useRef(null);
  const main = useRef(null);
  const ad = useRef(null);
  const adContainer = useRef(null);

  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [paused, setPaused] = useState(true);
  const [rate, setRate] = useState(1);
  const [vol, setVol] = useState(1);
  const [visible, setVisible] = useState(true);
  const [locked, setLocked] = useState(false);
  const [bright, setBright] = useState(0.5);
  const [showSpeed, setShowSpeed] = useState(false);
  const [pip, setPip] = useState(false);
  const adCount = useRef(0);

  const [ads, setAds] = useState([]);
  const [intervalMin, setIntervalMin] = useState(3);
  const [adPlaying, setAdPlaying] = useState(false);

  const seeking = useRef(false);
  const hideT = useRef(null);
  const nextAd = useRef(null);
  const triggering = useRef(false);
  const imageAdTimer = useRef(null);

  /* ---------------- Fetch Ads ---------------- */
  useEffect(() => {
    fetch(ADS_API)
      .then((r) => r.json())
      .then((d) => {
        const allAds = Array.isArray(d)
          ? d.filter((url) => isImage(url) || isVideo(url))
          : [];
        setAds(allAds);
      })
      .catch((err) => console.error("❌ Error fetching ads:", err));

    fetch(INTERVAL_API)
      .then((r) => r.json())
      .then((d) => {
        if (typeof d?.minutes === "number") {
          setIntervalMin(d.minutes);
        }
      })
      .catch((err) => console.error("❌ Error reading interval:", err));
  }, []);

  const showControls = () => {
    if (locked) return;
    clearTimeout(hideT.current);
    setVisible(true);
    if (!paused) hideT.current = setTimeout(() => setVisible(false), 3000);
  };

  const changeRate = (r) => {
    if (!main.current) return;
    main.current.playbackRate(r);
    setRate(r);
  };

  const toggleFS = async () =>
    document.fullscreenElement
      ? document.exitFullscreen()
      : container.current?.requestFullscreen().catch(() => {});

  const togglePiP = async () => {
    const v = main.current?.tech()?.el();
    if (!v) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPip(false);
      } else {
        await v.requestPictureInPicture();
        setPip(true);
      }
    } catch { /* empty */ }
  };

  /* ---------------- Ad Start ---------------- */
  const startAd = () => {
    if (!ads.length || adPlaying || triggering.current) return;

    const url = ads[Math.floor(Math.random() * ads.length)];
    const p = main.current;
    if (!url || !p) return;

    const resume = p.currentTime();
    p.pause();

    triggering.current = true;
    setAdPlaying(true);
    setPaused(true);

    wrap.current.style.visibility = "hidden";

    const adDiv = document.createElement("div");
    adDiv.className = "ad-overlay";

    adContainer.current = adDiv;
    container.current.appendChild(adDiv);

    const endAd = () => {
      if (imageAdTimer.current) {
        clearTimeout(imageAdTimer.current);
        imageAdTimer.current = null;
      }

      if (ad.current) {
        ad.current.dispose();
        ad.current = null;
      }

      if (adContainer.current) {
        adContainer.current.remove();
        adContainer.current = null;
      }

      if (wrap.current) {
        wrap.current.style.visibility = "visible";
      }

      p.currentTime(resume);
      p.play();

      setAdPlaying(false);
      setPaused(false);
      triggering.current = false;

      const intSec = Math.max(1, intervalMin * 60);
      adCount.current += 1;
      nextAd.current = (adCount.current + 1) * intSec;
    };

    if (isImage(url)) {
      const img = document.createElement("img");
      img.src = url;
      img.classList.add("preview-image");
      img.onerror = () => {
        console.error("❌ Image ad failed to load:", url);
        endAd();
      };

      img.onload = () => {
        console.log("✅ Image ad loaded successfully");
      };

      adDiv.appendChild(img);
      imageAdTimer.current = setTimeout(endAd, IMAGE_AD_DURATION * 1000);
      return;
    }

    if (isVideo(url)) {
      const vid = document.createElement("video");
      vid.className = "video-js vjs-default-skin";
      vid.setAttribute("playsinline", "");
      vid.setAttribute("webkit-playsinline", "");

      adDiv.appendChild(vid);

      const adPlayer = videojs(vid, {
        controls: false,
        autoplay: true,
        preload: "auto",
        muted: false,
        sources: [{ src: url, type: "video/mp4" }],
      });

      ad.current = adPlayer;

      adPlayer.on("error", endAd);

      adPlayer.on("ended", endAd);

      adPlayer.ready(() => {
        console.log("✅ Ad player ready, playing:", url);
      });
    }
  };

  /* ---------------- Build Player ---------------- */
  useEffect(() => {
    if (!videoSource) {
      main.current?.dispose();
      wrap.current.innerHTML = "";
      return;
    }

    main.current?.dispose();
    wrap.current.innerHTML = "";

    if (isImage(videoSource)) {
      const img = document.createElement("img");
      img.src = videoSource;
      img.className = "main-image";
      wrap.current.appendChild(img);
      return;
    }

    const el = document.createElement("video");
    el.className = "video-js vjs-default-skin";
    el.setAttribute("playsinline", "");
    el.setAttribute("webkit-playsinline", "");
    wrap.current.appendChild(el);

    const player = videojs(el, {
      controls: false,
      preload: "auto",
      autoplay: true,
      fluid: true,
      sources: [{ src: videoSource, type: "video/mp4" }],
      playbackRates: [0.5, 1, 1.25, 1.5, 2],
    });

    main.current = player;
    setVol(player.volume());

    // const resume = getResume();
    player.on("loadedmetadata", () => {
      const dur = player.duration();
      setDuration(dur);

      const lastSrc = localStorage.getItem(LAST_SRC_KEY);
      const lastTime = parseFloat(localStorage.getItem(LAST_TIME_KEY) || "0");

      let resumeTime = 0;

      if (lastSrc === videoSource && lastTime > 3) {
        resumeTime = Math.min(dur - 1, lastTime);
        player.currentTime(resumeTime);
        console.log("⏱ Restored time:", resumeTime);
      } else {
        console.log("⏱ No restore");
      }

      setCurrent(resumeTime);

      const intSec = Math.max(1, intervalMin * 60);
      adCount.current = Math.floor(resumeTime / intSec);
      nextAd.current = (adCount.current + 1) * intSec;
    });

    player.on("timeupdate", () => {
      if (adPlaying) return;

      const t = player.currentTime();
      if (!seeking.current) setCurrent(t);

      if (!triggering.current && t >= nextAd.current) {
        console.log("🚀 Ad Trigger at:", fmt(t));
        startAd();
      }
    });

    player.on("pause", () => {
      if (!adPlaying) setPaused(true);
    });

    player.on("play", () => !adPlaying && setPaused(false));
    player.on("volumechange", () => setVol(player.volume()));
    player.on("ended", () => goToNext?.());

    return () => player.dispose();
  }, [videoSource, intervalMin]);

  // ⏳ SAVE VIDEO TIME EVERY 2 SECONDS
  useEffect(() => {
    const interval = setInterval(() => {
      const player = main.current;
      if (!player || player.isDisposed()) return;

      localStorage.setItem(LAST_SRC_KEY, videoSource);
      localStorage.setItem(LAST_TIME_KEY, player.currentTime());
    }, 2000);

    return () => clearInterval(interval);
  }, [videoSource]);

  /* ---------------- UI Handlers ---------------- */
  const togglePlay = () => {
    if (locked || adPlaying) return;
    const p = main.current;
    p.paused() ? p.play() : p.pause();
    showControls();
  };

  const seek = (v) => {
    if (locked || adPlaying) return;
    setCurrent(v);
    main.current.currentTime(v);

    const intSec = Math.max(1, intervalMin * 60);
    nextAd.current = (Math.floor(v / intSec) + 1) * intSec;
  };

  useEffect(() => {
    const handleOffline = () => {
      localStorage.removeItem(LAST_SRC_KEY);
      localStorage.removeItem(LAST_TIME_KEY);
    };

    window.addEventListener("offline", handleOffline);
    return () => window.removeEventListener("offline", handleOffline);
  }, []);

  /* ---------------- Render ---------------- */
  return (
    <div
      className={`vp-container ${locked ? "locked" : ""}`}
      ref={container}
      onClick={showControls}
    >
      {!videoSource && (
        <div className="no-video-message">
          <h3>Select a video to begin playing.</h3>
        </div>
      )}

      <div
        ref={wrap}
        className="video-wrapper"
        style={{
          filter: `brightness(${0.5 + Number(bright)})`,
        }}
      />

      {videoSource && (
        <>
          {!locked && !adPlaying && (
            <div className={`center-controls ${visible ? "show" : ""}`}>
              <button
                onClick={() => seek(Math.max(0, current - 10))}
                className="jump-btn"
              >
                <div className="jump-icon">↻</div>
                <div className="jump-text">10</div>
              </button>

              <button onClick={togglePlay} className="play-main-btn">
                {paused ? "▶" : "⏸"}
              </button>

              <button
                onClick={() => seek(Math.min(duration, current + 10))}
                className="jump-btn"
              >
                <div className="jump-icon rotate">↻</div>
                <div className="jump-text">10</div>
              </button>
            </div>
          )}

          <button
            className={`lock-btn ${visible ? "show" : ""} ${
              locked ? "active" : ""
            }`}
            onClick={() => setLocked((x) => !x)}
          >
            {locked ? "🔒" : "🔓"}
          </button>

          {!locked && !adPlaying && (
            <div
              className={`right-vertical-brightness ${visible ? "show" : ""}`}
            >
              <div>☀️</div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                className="vertical-slider"
                value={bright}
                onChange={(e) => setBright(e.target.value)}
              />
            </div>
          )}

          {!locked && !adPlaying && (
            <div className={`left-vertical-volume ${visible ? "show" : ""}`}>
              <div>🔊</div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                className="vertical-slider"
                value={vol}
                onChange={(e) => {
                  main.current.volume(e.target.value);
                  setVol(e.target.value);
                }}
              />
            </div>
          )}

          {!locked && !adPlaying && (
            <div className={`bottom-controls sleek ${visible ? "show" : ""}`}>
              <input
                id="seekbar"
                type="range"
                min={0}
                max={duration}
                step="0.1"
                value={current}
                onChange={(e) => seek(Number(e.target.value))}
                className="seekbar-full"
              />

              <div className="controls-row">
                <div className="controls-left">
                  <button
                    className="control-btn prev-btn"
                    onClick={goToPrevious}
                    disabled={!canGoPrevious}
                  >
                    ⏮
                  </button>
                  <div className="time-display">
                    {fmt(current)} / {fmt(duration)}
                  </div>
                  <button
                    className="control-btn next-btn"
                    onClick={goToNext}
                    disabled={!canGoNext}
                  >
                    ⏭
                  </button>
                </div>

                <div className="controls-right">
                  <button className="control-btn pip-btn" onClick={togglePiP}>
                    {pip ? "⤧" : "⧉"}
                  </button>

                  <div className="speed-menu">
                    <button
                      className="control-btn speed-btn"
                      onClick={() => setShowSpeed(!showSpeed)}
                    >
                      {rate}x
                    </button>
                    {showSpeed && (
                      <div className="speed-dropdown">
                        {[0.5, 1, 1.25, 1.5, 2].map((r) => (
                          <div
                            key={r}
                            className={`speed-option ${
                              r === rate ? "active" : ""
                            }`}
                            onClick={() => {
                              changeRate(r);
                              setShowSpeed(false);
                            }}
                          >
                            {r}x
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <button
                    className="control-btn fullscreen-btn"
                    onClick={toggleFS}
                  >
                    ⛶
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
