/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react'
import MarqueeWithBack from '../Component/MarqueeWithBack'
import Banner from '../Component/Banner'
import Footer from '../Component/Footer'
import '../Css/Journey.css'
import { io } from 'socket.io-client';

const Journey = () => {
  const SERVER_PORT = import.meta.env.VITE_SERVER_PORT || 5000;
  const SERVER_HOST = import.meta.env.VITE_SERVER_HOST || "192.168.0.243"; // Replace with actual IP
  let serverUrl = `http://${SERVER_HOST}:${SERVER_PORT}`;

  const [journeyData, setJourneyData] = useState({
    adtns: null, // Approx distance to next station
    ss: null,  // Source station
    ns: null,  // Next station
    ds: null,  // Destination station
  });

  useEffect(() => {
    if (typeof window !== "undefined") {
      // Browser environment
      serverUrl = `${window.location.protocol}//${window.location.hostname}:${import.meta.env.VITE_SERVER_PORT}`;
    }

    const socket = io(serverUrl, {
      transports: ["websocket"], // Ensure compatibility with mobile devices
    });

    socket.on('connect', () => {
      // console.log('WebSocket Connected:', socket.id);
    });

    // Listen for UDP data and update state
    socket.on('udpData', (message) => {
      if (message) {
        setJourneyData({
          adtns: message.distanceInMeters || 'N/A',
          ss: message.sourceStationName || 'N/A',
          ns: message.nextStationName || 'N/A',
          ds: message.destinationStationName || 'N/A'
        });
      }
    });

    return () => {
      socket.disconnect(); // Clean up WebSocket connection on unmount
    };
  }, []);

  const loadingText = "Updating information, please wait...";

  return (
    <div onContextMenu={(e) => e.preventDefault()}>
      <MarqueeWithBack />
      <Banner />
      <div className="journey-timeline">
        <div className="timeline-header">
          <h2>🚆 Journey Status</h2>
        </div>
        <div className="timeline">
          {/* Source Station */}
          <div className="timeline-item">
            <div className="timeline-icon">🚉</div>
            <div className="timeline-content">
              <h4>Source Station</h4>
              <p><strong>{journeyData.ss ?? loadingText}</strong></p>
            </div>
          </div>

          {/* Next Station */}
          <div className="timeline-item">
            <div className="timeline-icon">⏩</div>
            <div className="timeline-content">
              <h4>Next Station</h4>
              <p><strong>{journeyData.ns ?? loadingText}</strong> <span className="status-badge upcoming">Upcoming</span></p>
            </div>
          </div>

          {/* Destination */}
          <div className="timeline-item">
            <div className="timeline-icon">🏁</div>
            <div className="timeline-content">
              <h4>Destination</h4>
              <p><strong>{journeyData.ds ?? loadingText}</strong></p>
            </div>
          </div>

          {/* Distance */}
          <div className="timeline-item">
            <div className="timeline-icon">📏</div>
            <div className="timeline-content">
              <h4>Approx. Distance to Next Station</h4>
              <div className="distance-bar">
                <div
                  className="distance-progress"
                  style={{ width: journeyData.adtns !== null ? `${100 - journeyData.adtns}%` : "0%" }}
                ></div>
              </div>
              <p>{journeyData.adtns !== null ? `${journeyData.adtns/1000} km` : loadingText}</p>
            </div>
          </div>

        </div>
        
      </div>
      <Footer />
    </div>
  );
}

export default Journey;
