/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MarqueeWithBack from "../Component/MarqueeWithBack";
import Banner from "../Component/Banner"; // Ensure this path is correct
import Footer from "../Component/Footer";
import "../Css/Tourist.css";
import useLogin from "@api/useLogin";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChevronLeft,
  faChevronRight,
} 
from "@fortawesome/free-solid-svg-icons";

import { decryptData } from '@api/cryptoUtils'


const Tourist = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fileList, setFileList] = useState([]);
  const [currentImageUrl, setCurrentImageUrl] = useState(null);
  const navigate = useNavigate();
  const { token } = useLogin();

  // Fetch list of files
  useEffect(() => {

      fetch(`/api/tourist`, {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in headers
        },
      })
        .then((response) => {
          if (!response.ok) throw new Error("Failed to fetch files");
          return response.json();
        })
        .then((data) => {
          // console.log(data)
          const decryptedData = data.map(item => ({
                          ...item,
                          name: decryptData(item.name), // Decrypt the file name
                        }));
          const filteredFiles = decryptedData.filter(
            (file) =>
              file.type === "file" &&
              (file.name.endsWith(".png") ||
                file.name.endsWith(".jpg") ||
                file.name.endsWith(".jpeg"))
          );
          setFileList(filteredFiles);
        })
        .catch((error) => console.error("Error fetching files:", error));
    
  }, [ token]);

  // Fetch current image
  useEffect(() => {
    if (fileList.length > 0) {
      const currentFileName = fileList[currentIndex].name;
      fetch(`/api/tourist/${currentFileName}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((response) => {
          if (!response.ok) throw new Error("Failed to fetch image");
          return response.blob();
        })
        .then((blob) => {
          const imageUrl = URL.createObjectURL(blob);
          setCurrentImageUrl(imageUrl);
        })
        .catch((error) => console.error("Error fetching image:", error));
    }
  }, [currentIndex, fileList,  token]);

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === fileList.length - 1 ? 0 : prevIndex + 1
    );
  };

  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? fileList.length - 1 : prevIndex - 1
    );
  };

  return (
    <>
      <MarqueeWithBack />
      <Banner /> {/* Ensure the Banner component renders */}
      <h1 className="tourist-heading" onContextMenu={(e) => e.preventDefault()}>
        Tourist Places
      </h1>
      <div className="slider_container_img">
        {currentImageUrl ? (
          <div
            className="sliderTourist"
            onContextMenu={(e) => e.preventDefault()}
          >
            <img
              alt={`Image ${currentIndex + 1}`}
              src={currentImageUrl}
              className="slider-image"
              onContextMenu={(e) => e.preventDefault()}
            />
          </div>
        ) : (
          <p>Loading images...</p>
        )}
        {fileList.length > 0 && (
          <>
            <button className="arrow left-arrow" onClick={handlePrev}>
              <FontAwesomeIcon icon={faChevronLeft} />
            </button>
            <button className="arrow right-arrow" onClick={handleNext}>
              <FontAwesomeIcon icon={faChevronRight} />
            </button>
          </>
        )}
      </div>
      <Footer />
    </>
  );
};

export default Tourist;
