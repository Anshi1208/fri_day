/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState, useRef } from 'react';
import MarqueeWithBack from '../Component/MarqueeWithBack';
import Banner from '../Component/Banner';
import Footer from '../Component/Footer';
import '../Css/Videos.css';
import Popup from '../Component/Popup';
import useLogin from '@api/useLogin'

import { decryptData } from '@api/cryptoUtils'

const Videos = () => {
  const [fileList, setFileList] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(-1);
  const [advertisementSeconds, setAdvertisementSeconds] = useState([]);
  const [advertisementData, setAdvertisementData] = useState(null);
  const videoRef = useRef(null);
  const adVideoRef = useRef(null); 
  const [isUserPaused, setIsUserPaused] = useState(false); 
  const audioRef = useRef(null)
  const savedTimeRef = useRef(0); 
  const [showAdvertisement, setShowAdvertisement] = useState(false);
  const [adMedia, setAdMedia] = useState(null); 
  const adTimesRef = useRef([]); // For ad times
  const [isAdShowing, setIsAdShowing] = useState(false);  
  const { token } = useLogin();
  const [imageSources, setImageSources] = useState({}); 
  const [loading, setLoading] = useState(true);
  const [bufferProgress, setBufferProgress] = useState(0); 


  const pauseMedia = () => {
    if (videoRef.current) {
      videoRef.current.pause() // Pause the video
    }
    if (audioRef.current) {
      audioRef.current.pause() // Pause the audio
    }
    setIsUserPaused(true); // Update the user pause state


    // If the video is paused, exit fullscre
    if (document.fullscreenElement) {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
    }

  }
  
  const resumeMedia = () => {
    if (videoRef.current) {
      // Set the current time before playing
      videoRef.current.play(); // Resume the video
    }
    if (audioRef.current) {
      audioRef.current.play(); // Resume the audio
    }
    setIsUserPaused(false); // Update the user pause state
  };


  const pauseAdMedia = () => {
    if (adVideoRef.current) {
      adVideoRef.current.pause(); // Resume the ad video if it was paused
    }
  }

  const resumeAdMedia = () => {

    if (adVideoRef.current) {
      adVideoRef.current.play(); // Resume the ad video if it was paused
    }
  }

useEffect(() => {
    Promise.all([
      fetch(`/api/videos`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }),
      fetch(`/api/advertisment`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }),
      fetch(`/api/database/videoAdvertismentTime.txt`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }),
    ])
    .then(([videosResponse, advertResponse, advertTimeResponse]) => {
      return Promise.all([
        videosResponse.json(),
        advertResponse.json(),
        advertTimeResponse.json(),
      ]);
    })
    .then(([videosData, advertData, advertTime]) => {
              const decryptedData = videosData.map(item => ({
                      ...item,
                      name: decryptData(item.name), // Decrypt the file name
                    }));
      const filteredvideos = decryptedData.map((directory) => {
        if (directory.type === 'directory') {
          // const filteredChildren = directory.children.filter((file) =>
          //   file.name.endsWith('.mp4')
          // );
          // Regular expression to match common video file extensions
          const videoExtensions = /\.(mp4|mkv|mov|webm)$/i;
          const filteredChildren = directory.children.filter((file) =>
            videoExtensions.test(file.name) // Test if file name ends with any of the common video extensions
        );
          
          return {
            ...directory,
            children: filteredChildren,
          };
        }
        return directory;
      });

      setFileList(filteredvideos);
      // Now, decrypt other data if necessary (for example, if VideoPosterData or advertData also needs decryption)
      const decryptedAdvertData = advertData.map(item => ({
        ...item,
        name: decryptData(item.name),
      }));
      setAdvertisementData(decryptedAdvertData);
      // Convert advertisement times from seconds to minutes
      const minutes = Math.floor(advertTime * 60); // Convert minutes to seconds
      setAdvertisementSeconds(minutes);
    })
    .catch((error) => console.error('Error fetching files:', error));
  
}, [ token]);


  useEffect(() => {
    if (fileList.length > 0 && !selectedCategory) {
      const firstCategory = fileList.find((file) => file.type === 'directory');
      if (firstCategory) {
        setSelectedCategory(firstCategory.name);
      }
    }
  }, [fileList, selectedCategory]);

  const categories = fileList.filter((file) => file.type === 'directory');

  const capitalizeFirstLetter = (string) => {
    if (!string) return '';
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  const renderCategory = (category) => (
    <div
      key={category.name}
      className={`category-box ${selectedCategory === category.name ? 'selected' : ''}`}
      onClick={() => setSelectedCategory(category.name)}
    >
      <strong>{capitalizeFirstLetter(category.name)}</strong>
    </div>
  );
      // UseEffect to reset the current video when changing categories
      useEffect(() => {
        if (selectedCategory) {
          setCurrentVideo(null); 
          setCurrentVideoIndex(-1); 
          setShowAdvertisement(false); // Stop the advertisement when category changes
          setAdMedia(null); // Reset ad media to null
          setIsAdShowing(false); // Reset ad showing state
        }
      }, [selectedCategory]);

  // Fetch images for posters
  useEffect(() => {
    const fetchImages = async (category) => {
      const videos = fileList.find((file) => file.name === category)?.children || [];
      const sources = {};

      for (const video of videos) {
        const videoName = video.name;
        // Extract the video extension (e.g., .mp4, .avi, .mkv, etc.)
        const videoExtension = videoName.split('.').pop();
        const jpgPosterPath = `/api/videos/${category}/${videoName.replace(`.${videoExtension}`, '.jpg')}`;
        const pngPosterPath = `/api/videos/${category}/${videoName.replace(`.${videoExtension}`, '.png')}`;
        const jfifPosterPath = `/api/videos/${category}/${videoName.replace(`.${videoExtension}`, '.jfif')}`;
        const defaultImage = `/api/default_img/folder_img.gif`;

        try {
          const jpgBlob = await fetch(jpgPosterPath, {
            headers: { Authorization: `Bearer ${token}` }
          });
          if (jpgBlob.ok) {
            sources[videoName] = URL.createObjectURL(await jpgBlob.blob());
          } 
          else {
            const pngBlob = await fetch(pngPosterPath, {
              headers: { Authorization: `Bearer ${token}` }
            });
            if (pngBlob.ok) {
              sources[videoName] = URL.createObjectURL(await pngBlob.blob());
            } 
            else {
              const jfifBlob = await fetch(jfifPosterPath, {
                headers: { Authorization: `Bearer ${token}` }
              });
              if (jfifBlob.ok) {
                sources[videoName] = URL.createObjectURL(await jfifBlob.blob());
              } 
              else {
                const defaultBlob = await fetch(defaultImage, {
                  headers: { Authorization: `Bearer ${token}` }
                });
                if (defaultBlob.ok) {
                  sources[videoName] = URL.createObjectURL(await defaultBlob.blob());
                } else {
                  sources[videoName] = `/api/default_img/folder_img.gif`;
                }
              }
            }
          }
        } catch {
          sources[videoName] = `/api/default_img/folder_img.gif`;
        }
      }

      setImageSources((prev) => ({ ...prev, ...sources })); // Update state with fetched sources
    };

    if (selectedCategory) {
      fetchImages(selectedCategory);
    }
  }, [selectedCategory, fileList,  token]);

  const renderPosters = (category) => {
    const videos = fileList.find((file) => file.name === category)?.children || [];
    return videos.map((video) => {
      const videoName = video.name;
      const imageSrc = imageSources[videoName] || `/api/default_img/folder_img.gif`;

      return (
        <div
          key={videoName}
          className="poster"
          onClick={() => handleVideoClick(videoName)}
        >
          <img
            src={imageSrc}
            alt={videoName}
            className="poster-image"
            loading="lazy"
          />
          <div className="video-name">{capitalizeFirstLetter(videoName).replace(/\.[^/.]+$/, '')}</div>
        </div>
      );
    });
  };

  const handleVideoClick = (videoName,index) => {
    if (isAdShowing) {
      setShowAdvertisement(false); // Stop the advertisement
      setIsAdShowing(false); // Reset ad showing state
      resumeMedia(); // Resume the video if the ad was playing
    }
    setCurrentVideo(videoName); 
  };

  useEffect(() => {
    if (currentVideo && videoRef.current) {
// Set the video source directly to the URL   
      const isMobileOrTablet = window.innerWidth <= 768;
      if (isMobileOrTablet) {
        videoRef.current.play();
        if (videoRef.current.requestFullscreen) {
          videoRef.current.requestFullscreen(); // Enter fullscreen
        } else if (videoRef.current.mozRequestFullScreen) {
          videoRef.current.mozRequestFullScreen();
        } else if (videoRef.current.webkitRequestFullscreen) {
          videoRef.current.webkitRequestFullscreen();
        } else if (videoRef.current.msRequestFullscreen) {
          videoRef.current.msRequestFullscreen();
        }
      }
    }
    
  }, [currentVideo,  selectedCategory]); // Ensure this runs after video element is available


    
  useEffect(() => {
    const exitFullscreenAndLockOrientation = async () => {
      // Exit fullscreen if the video is in fullscreen
      if (document.fullscreenElement) {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
          await document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
          await document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
          await document.msExitFullscreen();
        }
      }

      // Lock to portrait mode if ad is showing
      if (isAdShowing) {
        if (screen.orientation && screen.orientation.lock) {
          try {
            await screen.orientation.lock('portrait');
          } catch (err) {
            console.error('Error locking screen orientation:', err);
          }
        } else {
          console.warn('Screen Orientation API not supported');
        }
      }
    };

    exitFullscreenAndLockOrientation();
  }, [isAdShowing]);

  // videoRef.current.src 

  useEffect(() => {
    if (currentVideo && videoRef.current) {
      const videoUrl = `/api/Api/videos/${selectedCategory}/${currentVideo}`;

      // Directly set the video source
      videoRef.current.src = videoUrl;
      videoRef.current.load();
  
      // Optionally play the video if desired
      videoRef.current.oncanplaythrough = () => {
        videoRef.current.play();
      };
    }
  }, [currentVideo,  selectedCategory]);
  


  const calculateAdTimes = () => {
    const duration = videoRef.current?.duration || 0;
    const times = []; 
    for (let i = advertisementSeconds; i < duration; i += advertisementSeconds) {
      times.push(i);
    }
    adTimesRef.current = times; 
  };

  // Display ad (either video or image)
  const displayAd = async () => {
    if (!isAdShowing) {
      // Select a random advertisement
      const ad = advertisementData[Math.floor(Math.random() * advertisementData.length)];
  
      const adUrl = `/api/advertisment/${ad.name}`;
      const headers = {
        Authorization: `Bearer ${token}`,
      };
  
      try {
        // Fetch the ad file as a blob (either video or image)
        const response = await fetch(adUrl, { headers });
        if (!response.ok) {
          console.error('Failed to fetch advertisement:', response.status);
          return;
        }
        // Get the response as a blob
        const blob = await response.blob();
  
        // Check if the ad is a video or an image
        // if (ad.name.endsWith('.mp4')) {
          if (/\.(mp4|mkv|mov|webm)$/i.test(ad.name)) {
            const videoUrl = URL.createObjectURL(blob); // Create object URL for the video
            setAdMedia({ type: 'video', src: videoUrl });
          } else if (/\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(ad.name)) {
            const imageUrl = URL.createObjectURL(blob); // Create object URL for the image
            setAdMedia({ type: 'image', src: imageUrl });
          }
          
  
        // Save the current video time before showing the ad
        savedTimeRef.current = videoRef.current.currentTime;
        setShowAdvertisement(true);
        pauseMedia(); // Pause the main video
        setIsAdShowing(true);
  
        // Show the ad for 5 seconds if it's an image
        if (ad.name.endsWith('.jpg') || ad.name.endsWith('.png')) {
          setTimeout(() => {
            setShowAdvertisement(false);
            setIsAdShowing(false);
            resumeMedia(); // Resume the main video
          }, 5000); // 5 seconds duration for image ad
        }
      } catch (error) {
        console.error('Error fetching advertisement:', error);
      }
    }
  };
  
  // Handle media state update when adMedia or showAdvertisement changes
  useEffect(() => {
  }, [adMedia, showAdvertisement]);

  // Video ad handling (resume main video after ad ends)
  const handleAdVideoEnd = () => {
    setShowAdvertisement(false);
    setIsAdShowing(false);
    resumeMedia();
  };

  const logCurrentTime = () => {
    const currentVideoRef = videoRef.current;
    if (currentVideoRef) {
      const currentTime = Math.floor(currentVideoRef.currentTime);
      if (!isAdShowing && adTimesRef.current.includes(currentTime)) {
        savedTimeRef.current = currentTime;
        displayAd();
      }
    }
  };
  

  useEffect(() => {
    const videoElement = videoRef.current;
    if (videoElement) {
      // Calculate ad times when video is loaded
      videoElement.addEventListener('loadedmetadata', calculateAdTimes);
      // Log current time every second
      const intervalId = setInterval(logCurrentTime, 1000);
      return () => {
        clearInterval(intervalId); 
        videoElement.removeEventListener('loadedmetadata', calculateAdTimes); 
      };
    }
  }, [logCurrentTime,calculateAdTimes]);

  const handleNextVideo = () => {
    const videos = fileList.find((file) => file.name === selectedCategory)?.children || [];
    // Find the index of the current video in the videos array
    const currentIndex = videos.findIndex((video) => video.name === currentVideo);
    // If currentIndex is valid, proceed to next video, otherwise start from the beginning
    if (currentIndex !== -1) {
      // Check if we're at the end of the list, and loop back to the first video if true
      const nextIndex = currentIndex >= videos.length - 1 ? 0 : currentIndex + 1;
      // Call handleVideoClick with the next video
      handleVideoClick(videos[nextIndex].name, nextIndex);
    } else {
      // Handle case when currentVideo is not found in videos (this shouldn't happen if the video is in the list)
      console.error('Current video not found in the list.');
    }
  };


  return (
    <>
      {/* Popup to show while data is being sent */}
      <Popup pauseMedia={pauseMedia} resumeMedia={resumeMedia} isUserPaused={isUserPaused} 
      pauseAdMedia = {pauseAdMedia} resumeAdMedia = {resumeAdMedia}/>
      <MarqueeWithBack />
      <Banner />
      <div className="video-container">
        <div className="categories-heading">
          <h2>videos Categories:</h2>
        </div>
        <div className="category-container" onContextMenu={(e) => e.preventDefault()}>
          {categories.map(renderCategory)}
        </div>

        {selectedCategory && (
          <>
            {currentVideo && (
                <div className={`current-video ${isAdShowing ? 'hide' : 'show'}`}>
                  <div>
                  <video
                    ref={videoRef}
                    controls
                    autoPlay
                    controlsList="nodownload"
                    disablePictureInPicture
                    width="600"
                    preload="auto"
                    onContextMenu={(e) => e.preventDefault()}
                    onEnded={handleNextVideo}
                    onPause={() => setIsUserPaused(true)} // Track user pause state
                    onPlay={() => setIsUserPaused(false)} // Reset user pause state
                  >
                    Your browser does not support the video tag.
                  </video>
                </div>
                <div className="current-videoName">
                  <strong>Now Playing:</strong>{' '}
                  {currentVideo.replace(/\.[^/.]+$/, '')}
                </div>
              </div>
            )}
            {showAdvertisement && adMedia?.type === 'image' && (
              <div className={`advertisement ${isAdShowing ? 'show' : 'hide'}`}>
                <img src={adMedia.src} alt="Ad" style={{ width: '80%' }} />
              </div>
            )}
            {showAdvertisement && adMedia?.type === 'video' && (
              <div className={`advertisement ${isAdShowing ? 'show' : 'hide'}`}>
                <video ref={adVideoRef} 
                autoPlay width="600"
                onEnded={handleAdVideoEnd} 
                onPause={pauseAdMedia}  // Call pauseMedia when the ad video is paused
                onPlay={resumeAdMedia}   // Call resumeMedia when the ad video is played
                >
              <source src={adMedia.src} type="video/mp4" />
            </video>
          </div>
        )}
            <div className="type-heading">
              <h2>videos in {capitalizeFirstLetter(selectedCategory)}:</h2>
            </div>
            <div className="poster-container" onContextMenu={(e) => e.preventDefault()}>
              {renderPosters(selectedCategory)}
            </div>
          </>
        )}
      </div>
      <Footer />
    </>
  );
};

export default Videos;
