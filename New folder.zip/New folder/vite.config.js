/* eslint-disable no-undef */
/* eslint-disable no-constant-binary-expression */
/* eslint-disable no-unused-vars */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path';
import loadEnv from './Api/loadEnv'   
//import loadEnv from './dist/Api/loadEnv' 

// Custom paths to search for .env file
const envPath = [ './.env','./dist/Api/.env'] // Define your custom search paths

// Call the loadEnv function with custom paths
const result = loadEnv(envPath);

const useDistApi = true;
// console.log(process.env.VITE_SERVER_PORT)
// https://vitejs.dev/config/
export default defineConfig({
  
  server: {
    port: process.env.VITE_PORT || 80 || 5179 || 5174, // Fallback to 3000 if not defined
    proxy: {
      '/api': {
        target: `http://localhost:${process.env.VITE_SERVER_PORT}`,
        changeOrigin: true,
        secure: false,
        credentials: true,
        rewrite: (path) => path.replace(/^\/api/, ''), // Remove `/api` prefix
      },
    }
  ,  
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@api': path.resolve(__dirname, useDistApi ? './Api' : './dist/Api'), // Alias to the Api folder
    },
  },


  preview: {
    port: process.env.PORT || 4173, // Port for preview server
  },
})
