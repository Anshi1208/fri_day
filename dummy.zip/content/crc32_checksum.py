import zlib

def calculate_crc32(file_path):
    try:
        with open(file_path, 'rb') as f:
            data = f.read()
            crc32 = zlib.crc32(data) & 0xFFFFFFFF
            return "{:08x}".format(crc32)
    except FileNotFoundError:
        return "File not found: {}".format(file_path)
    except Exception as e:
        return "An error occurred: {}".format(e)

file_path = 'movies/bollywood/animal.mp4'
checksum = calculate_crc32(file_path)
print("CRC32 checksum of {}: {}".format(file_path, checksum.upper()))
