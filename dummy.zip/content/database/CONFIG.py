import zlib
import os
import time


def parse_config_file(file_path):
    data = {}
    with open(file_path, 'r') as file:
        for line in file:
            # Skip empty lines and lines starting with a comment
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # Split the line by whitespace and separate values
            parts = line.split()
            if len(parts) == 3:
                crc, size, filename = parts
                # Normalize the filename by removing extra spaces around it
                filename = filename.strip()
                # Skip header lines
                if crc.upper() == "CRC" and size.upper() == "SIZE" and filename.upper() == "FILENAME":
                    continue
                # Ensure CRC and size are in correct format
                if len(crc) == 8 and size.isdigit():
                    data[filename] = crc
                else:
                    print("Warning: Invalid data line skipped: {}".format(line))
            else:
                print("Warning: Invalid line format skipped: {}".format(line))

    return data



def calculate_crc32(file_path):
    """Calculate the CRC32 checksum of a file."""
    try:
        with open(file_path, 'rb') as f:
            file_data = f.read()
        return format(zlib.crc32(file_data) & 0xFFFFFFFF, '08X')
    except FileNotFoundError:
        return None

def check_file_existence(file_dict, base_path):
    """Check if files exist in the specified directory."""
    for filename in file_dict.keys():
        # Construct the full path by joining the base directory with the filename
        full_path = os.path.join(base_path+ filename)
        # Calculate the relative path
        relative_path = os.path.relpath(full_path)
        if os.path.exists(full_path):
            print("Filename: {}, Status: Exists".format(relative_path))
        else:
            print("Filename: {}, Status: Does not exist".format(relative_path))

def verify_crc(file_dict, base_path):
    """Verify the CRC32 checksum of existing files."""
    for filename, expected_crc in file_dict.items():
        # Construct the full path by joining the base directory with the filename
        full_path = os.path.join(base_path+ filename)
        # Calculate the relative path
        relative_path = os.path.relpath(full_path)
        if os.path.exists(full_path):
            # Calculate the actual CRC32 checksum of the file
            actual_crc = calculate_crc32(full_path)
            if actual_crc is None:
                print("Filename: {}, Status: Error reading file".format(relative_path))
            elif actual_crc == expected_crc:
                print("Filename: {}, CRC: {}, Status: CRC matches".format(relative_path, expected_crc))
            else:
                print("Filename: {}, Expected CRC: {}, Actual CRC: {}, Status: CRC does not match".format(relative_path, expected_crc, actual_crc))
                os.remove(full_path)  # Remove the file
                print("Filename: {}, Status: File Deleted".format(relative_path,))

        else:
            print("Filename: {}, Status: Does not exist".format(relative_path))

def main():
    # Path to the config.sys file
    config_file_path = "/usr/share/apache2/htdocs/content/database/CONFIG.SYS"

    # Base directory to check file existence and verify CRC
    base_directory = "/usr/share/apache2/htdocs"

    # Initial run
    last_modified_time = None
    while True:
        try:
            # Check the last modification time of the config file
            current_modified_time = os.path.getmtime(config_file_path)
            if last_modified_time is None or current_modified_time != last_modified_time:
                print("Config file modified. Rerunning program...")
                # Parse the config file
                config_data = parse_config_file(config_file_path)
                # Check if files exist
                check_file_existence(config_data, base_directory)
                # Verify CRC of existing files
                verify_crc(config_data, base_directory)
                # Update the last modified time
                last_modified_time = current_modified_time
            # Sleep for a while before checking again
            time.sleep(1)
        except KeyboardInterrupt:
            print("Exiting...")
            break

if __name__ == "__main__":
    main()